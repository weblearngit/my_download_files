"""统一配置管理，使用 pydantic-settings 读取 .env 文件"""
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppConfig(BaseSettings):
    """应用基础配置"""
    name: str = "MyBian"
    version: str = "0.1.0"
    debug: bool = False
    
    model_config = SettingsConfigDict(
        case_sensitive=False
    )


class ServerConfig(BaseSettings):
    """服务器配置"""
    host: str = "0.0.0.0"
    port: int = 8000
    
    model_config = SettingsConfigDict(
        case_sensitive=False
    )


class LogConfig(BaseSettings):
    """日志配置"""
    level: str = "INFO"
    file: Optional[str] = None
    
    model_config = SettingsConfigDict(
        case_sensitive=False
    )


class DatabaseConfig(BaseSettings):
    """数据库配置"""
    url: Optional[str] = None
    
    model_config = SettingsConfigDict(
        case_sensitive=False
    )


class BinanceConfig(BaseSettings):
    """币安API配置"""
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    base_url: str = "https://api.binance.com"
    proxy: Optional[str] = None  # 格式: http://user:pass@host:port 或 http://host:port
    
    model_config = SettingsConfigDict(
        case_sensitive=False
    )


class Settings(BaseSettings):
    """应用配置类"""
    
    app: AppConfig = Field(default_factory=AppConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    log: LogConfig = Field(default_factory=LogConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    binance: BinanceConfig = Field(default_factory=BinanceConfig)
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        env_nested_delimiter="__"  # 支持嵌套结构，使用双下划线分隔
    )


# 全局配置实例
settings = Settings()

