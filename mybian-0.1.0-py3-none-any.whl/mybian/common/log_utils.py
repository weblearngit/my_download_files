"""日志初始化工具"""
import logging
import sys
import time
from pathlib import Path
from typing import Optional, Any, Callable
from functools import wraps


def setup_logging(
    log_level: str = "INFO",
    log_file: Optional[Path] = None,
    log_format: Optional[str] = None
) -> logging.Logger:
    """
    初始化日志配置
    
    Args:
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: 日志文件路径，如果为None则只输出到控制台
        log_format: 日志格式，如果为None则使用默认格式
    
    Returns:
        配置好的根日志记录器
    """
    if log_format is None:
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # 设置日志级别
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    # 配置根日志记录器
    handlers = []
    
    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(logging.Formatter(log_format))
    handlers.append(console_handler)
    
    # 文件处理器（如果指定了日志文件）
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(logging.Formatter(log_format))
        handlers.append(file_handler)
    
    # 配置根日志记录器
    logging.basicConfig(
        level=numeric_level,
        format=log_format,
        handlers=handlers,
        force=True  # 强制重新配置
    )
    
    logger = logging.getLogger(__name__)
    logger.info(f"日志系统初始化完成，日志级别: {log_level}")
    if log_file:
        logger.info(f"日志文件: {log_file}")
    
    return logging.getLogger()


def get_logger(name: str) -> logging.Logger:
    """
    获取指定名称的日志记录器
    
    Args:
        name: 日志记录器名称，通常使用 __name__
    
    Returns:
        日志记录器实例
    """
    return logging.getLogger(name)


def _format_argument(value: Any, max_length: int = 100, max_dict_items: int = 10) -> str:
    """
    格式化参数值用于日志输出
    
    Args:
        value: 参数值
        max_length: 最大输出长度
        max_dict_items: 字典最大显示项数
        
    Returns:
        格式化后的字符串
    """
    # 敏感字段，需要隐藏
    sensitive_keys = {'api_secret', 'api_key', 'secret', 'password', 'token', 'signature'}
    
    if value is None:
        return "None"
    
    # 字符串类型
    if isinstance(value, str):
        # 检查是否包含敏感信息
        value_lower = value.lower()
        if any(key in value_lower for key in sensitive_keys):
            return "***"
        if len(value) > max_length:
            return f"'{value[:max_length]}...'"
        return f"'{value}'"
    
    # 数值类型
    if isinstance(value, (int, float, bool)):
        return str(value)
    
    # 字典类型
    if isinstance(value, dict):
        if not value:
            return "{}"
        filtered_dict = {}
        items_count = 0
        for k, v in value.items():
            if items_count >= max_dict_items:
                filtered_dict["..."] = f"还有{len(value) - max_dict_items}项"
                break
            if isinstance(k, str) and any(key in k.lower() for key in sensitive_keys):
                filtered_dict[k] = "***"
            else:
                v_str = _format_argument(v, max_length=50, max_dict_items=3)
                if len(v_str) > 50:
                    v_str = v_str[:50] + "..."
                filtered_dict[k] = v_str
            items_count += 1
        dict_str = str(filtered_dict)
        if len(dict_str) > max_length:
            return f"{dict_str[:max_length]}..."
        return dict_str
    
    # 列表或元组
    if isinstance(value, (list, tuple)):
        if not value:
            return "[]"
        items = [_format_argument(item, max_length=50, max_dict_items=3) for item in value[:5]]  # 只显示前5个
        items_str = ", ".join(items)
        if len(value) > 5:
            items_str += f", ... (共{len(value)}项)"
        return f"[{items_str}]"
    
    # 其他类型（对象、类等）
    value_str = str(value)
    if len(value_str) > max_length:
        return f"{value_str[:max_length]}..."
    return value_str


def log_execution_time(func: Callable) -> Callable:
    """
    记录方法执行时间的装饰器，包括方法调用参数
    
    Args:
        func: 要装饰的方法
        
    Returns:
        装饰后的方法
    """
    logger = logging.getLogger(func.__module__)
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        method_name = func.__name__
        start_time = time.time()
        
        # 格式化参数用于日志输出
        # 跳过第一个参数（通常是self）
        args_str = ", ".join(_format_argument(arg) for arg in args[1:]) if len(args) > 1 else ""
        kwargs_str = ", ".join(f"{k}={_format_argument(v)}" for k, v in kwargs.items()) if kwargs else ""
        
        # 组合参数字符串
        params_parts = []
        if args_str:
            params_parts.append(args_str)
        if kwargs_str:
            params_parts.append(kwargs_str)
        params_str = ", ".join(params_parts) if params_parts else "无参数"
        
        # 限制参数字符串总长度，避免日志过长
        max_params_length = 500
        if len(params_str) > max_params_length:
            params_str = params_str[:max_params_length] + "..."
        
        try:
            result = func(*args, **kwargs)
            elapsed_time = time.time() - start_time
            logger.info(f"[执行时间] {method_name}({params_str}): {elapsed_time:.3f}秒")
            return result
        except Exception as e:
            elapsed_time = time.time() - start_time
            logger.info(f"[执行时间] {method_name}({params_str}): {elapsed_time:.3f}秒 (异常: {type(e).__name__})")
            raise
    return wrapper

