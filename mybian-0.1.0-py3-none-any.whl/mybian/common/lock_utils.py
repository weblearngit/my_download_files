# -*- coding: utf-8 -*-
"""标志文件管理工具，用于防止多进程同时处理同一账号"""
import os
import sys
import atexit
from pathlib import Path
from typing import Optional
from mybian.common.log_utils import get_logger

# 跨平台文件锁
if sys.platform != 'win32':
    import fcntl

logger = get_logger(__name__)

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logger.warning("psutil未安装，无法检测僵尸进程，建议安装: pip install psutil")


class LockFile:
    """标志文件管理器，使用文件锁机制防止并发"""
    
    def __init__(self, lock_file_path: Path, account_id: str):
        """
        初始化标志文件管理器
        
        Args:
            lock_file_path: 标志文件路径
            account_id: 账号标识（用于区分不同账号）
        """
        self.lock_file_path = lock_file_path
        self.account_id = account_id
        self.lock_file = None
        self.acquired = False
        
        # 注册退出时清理
        atexit.register(self.release)
    
    def acquire(self) -> bool:
        """
        尝试获取标志文件锁
        
        Returns:
            True表示成功获取锁，False表示已有其他进程持有锁
        """
        try:
            # 确保目录存在
            self.lock_file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 检查是否已有标志文件存在
            if self.lock_file_path.exists():
                # 检查是否是僵尸锁
                if self._is_stale_lock():
                    logger.warning(f"检测到僵尸标志文件，尝试清理: {self.lock_file_path}")
                    try:
                        self.lock_file_path.unlink()
                    except Exception as e:
                        logger.error(f"清理僵尸标志文件失败: {e}")
                        return False
                else:
                    # 标志文件存在且进程还在运行
                    logger.error(f"无法获取标志文件锁，可能有其他进程正在运行: {self.lock_file_path}")
                    return False
            
            # 打开标志文件（创建模式）
            self.lock_file = open(self.lock_file_path, 'w')
            
            # 在Unix/Linux系统上使用文件锁
            if sys.platform != 'win32':
                try:
                    fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                except (IOError, OSError):
                    # 无法获取锁
                    self.lock_file.close()
                    self.lock_file = None
                    if self.lock_file_path.exists():
                        self.lock_file_path.unlink()
                    logger.error(f"无法获取标志文件锁，可能有其他进程正在运行: {self.lock_file_path}")
                    return False
            
            # 获取锁成功，写入进程信息
            self.lock_file.seek(0)
            self.lock_file.truncate()
            pid = os.getpid()
            self.lock_file.write(f"{pid}\n{self.account_id}\n")
            self.lock_file.flush()
            
            self.acquired = True
            logger.info(f"成功获取标志文件锁: {self.lock_file_path} (PID: {pid}, 账号: {self.account_id})")
            return True
            
        except Exception as e:
            logger.error(f"获取标志文件锁时出错: {e}")
            if self.lock_file:
                try:
                    self.lock_file.close()
                except:
                    pass
                self.lock_file = None
            return False
    
    def _is_stale_lock(self) -> bool:
        """
        检查标志文件是否是僵尸锁（进程已不存在）
        
        Returns:
            True表示是僵尸锁，False表示进程仍存在
        """
        try:
            if not self.lock_file_path.exists():
                return False
            
            with open(self.lock_file_path, 'r') as f:
                lines = f.readlines()
                if len(lines) < 1:
                    return True
                
                try:
                    pid = int(lines[0].strip())
                except (ValueError, IndexError):
                    return True
                
                # 检查进程是否存在
                if not PSUTIL_AVAILABLE:
                    # 如果没有psutil，使用os.kill检查（Windows不可用）
                    if sys.platform != 'win32':
                        try:
                            os.kill(pid, 0)  # 发送0信号，不实际杀死进程，只检查是否存在
                            return False  # 进程存在，假设是我们的进程
                        except (OSError, ProcessLookupError):
                            return True  # 进程不存在
                    else:
                        return False  # Windows上没有psutil时，假设进程存在
                
                if not psutil.pid_exists(pid):
                    return True
                
                # 检查进程是否真的是我们的进程（通过命令行参数判断）
                try:
                    process = psutil.Process(pid)
                    # 检查进程的命令行参数中是否包含账号标识
                    cmdline = ' '.join(process.cmdline())
                    if self.account_id in cmdline:
                        return False  # 进程存在且是我们的进程
                    else:
                        return True  # 进程存在但不是我们的进程（可能是误判）
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    return True  # 进程不存在或无权限访问
                    
        except Exception as e:
            logger.warning(f"检查僵尸锁时出错: {e}")
            return False
    
    def release(self):
        """释放标志文件锁"""
        if not self.acquired:
            return
        
        try:
            if self.lock_file:
                if sys.platform != 'win32':
                    # Unix/Linux使用fcntl解锁
                    try:
                        fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                    except:
                        pass
                self.lock_file.close()
                self.lock_file = None
            
            # 删除标志文件
            if self.lock_file_path.exists():
                self.lock_file_path.unlink()
                logger.info(f"已释放标志文件锁: {self.lock_file_path}")
            
            self.acquired = False
        except Exception as e:
            logger.error(f"释放标志文件锁时出错: {e}")
    
    def __enter__(self):
        """上下文管理器入口"""
        if not self.acquire():
            raise RuntimeError(f"无法获取标志文件锁: {self.lock_file_path}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.release()

