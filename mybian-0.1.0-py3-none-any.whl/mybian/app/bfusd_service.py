# -*- coding: utf-8 -*-
"""BFUSD交易服务 - 通过USDT购买BFUSD然后快速赎回的循环交易"""
import time
import sys
from typing import Dict, Any, Optional
from mybian.common.log_utils import get_logger, log_execution_time
from mybian.app.base_service import BaseBinanceService, BINANCE_API_BASE_URL

logger = get_logger(__name__)


# 自定义异常类
class BFUSDTradingException(Exception):
    """BFUSD交易异常基类"""
    pass


class QuotaExhaustedException(BFUSDTradingException):
    """额度耗尽异常：freeQuota或leftQuota为0，需要退出进程"""
    pass


class TradingConditionException(BFUSDTradingException):
    """交易条件不满足异常：可忽略，等待下一轮重试"""
    pass


class BFUSDService(BaseBinanceService):
    """BFUSD交易服务类"""

    def __init__(
            self,
            api_key: Optional[str] = None,
            api_secret: Optional[str] = None,
            base_url: str = BINANCE_API_BASE_URL,
            proxy: Optional[str] = None,
            timeout: int = 30
    ):
        """
        初始化BFUSD服务
        
        Args:
            api_key: 币安API密钥
            api_secret: 币安API密钥
            base_url: API基础URL
            proxy: 代理地址，格式: http://user:pass@host:port 或 http://host:port
            timeout: 请求超时时间（秒）
        """
        super().__init__(api_key, api_secret, base_url, proxy, timeout)

        # 快速赎回速率限制：记录上次调用时间
        self.last_bfusd_redeem_time = 0.0

        logger.info(f"BFUSD服务初始化完成")

    @log_execution_time
    def get_fast_redemption_quota(self) -> Dict[str, Any]:
        """
        获取快速赎回配额
        
        Returns:
            包含fastRedemptionQuota和standardRedemptionQuota的字典
        """
        endpoint = "/sapi/v1/bfusd/quota"
        response = self._make_request('GET', endpoint, signed=True)

        quota_info = {
            'fast_redemption': response.get('fastRedemptionQuota', {}),
            'standard_redemption': response.get('standardRedemptionQuota', {}),
            'subscribe_enable': response.get('subscribeEnable', False),
            'redeem_enable': response.get('redeemEnable', False)
        }

        logger.info(f"快速赎回配额: {quota_info['fast_redemption']}")
        return quota_info


    @log_execution_time
    def fast_redeem_bfusd(self, amount: float) -> Dict[str, Any]:
        """
        快速赎回BFUSD（贪婪原则：尽可能多地使用免费额度）
        
        Args:
            amount: 赎回数量
            
        Returns:
            包含赎回信息的字典
            
        Raises:
            TradingConditionException: 快速赎回失败时抛出，可等待下一轮重试
            
        Note:
            速率限制: 1/3s per account，即每3秒最多调用一次
        """
        endpoint = "/sapi/v1/bfusd/redeem"
        # 格式化数量，确保符合精度要求
        amount_str = self._format_decimal(amount, precision=8)
        params = {
            'amount': amount_str,
            'type': 'FAST'  # 快速赎回
        }

        # 遵守速率限制：1/3s per account，即至少间隔3秒
        current_time = time.time()
        time_since_last_redeem = current_time - self.last_bfusd_redeem_time
        min_interval = 4  # 最小间隔3秒

        if time_since_last_redeem < min_interval:
            wait_time = min_interval - time_since_last_redeem
            logger.debug(f"遵守速率限制，等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)

        # 更新最后调用时间
        self.last_bfusd_redeem_time = time.time()

        response = self._make_request('POST', endpoint, params=params, signed=True)

        if not response.get('success'):
            logger.error(f"快速赎回失败: {response}")
            raise TradingConditionException(f"快速赎回失败: {response}")

        receive_amount = float(response.get('receiveAmount', 0))
        fee = float(response.get('fee', 0))

        logger.info(f"快速赎回成功: 数量={amount}, 收到={receive_amount:.2f}, 手续费={fee:.2f}")

        return {
            'receive_amount': receive_amount,
            'fee': fee
        }

    @log_execution_time
    def _redeem_all_bfusd_greedy(
            self,
            bfusd_balance: Optional[float] = None,
            quota_data: Optional[Dict[str, Any]] = None,
            buy_quantity: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        赎回BFUSD，根据是否有免费额度选择不同的赎回策略
        
        - 有免费额度：贪婪赎回，一次性赎回 min(当前持有的BFUSD, 免费额度)
        - 没有免费额度：只赎回购买的BFUSD数量
        
        Args:
            bfusd_balance: BFUSD余额，如果不提供则自动查询
            quota_data: 快速赎回配额数据，如果不提供则自动查询（避免重复查询）
            buy_quantity: 购买的BFUSD数量（仅在没有免费额度时使用）
        
        Returns:
            包含赎回信息的字典
            
        Raises:
            QuotaExhaustedException: 额度不足时抛出，需要退出进程
            TradingConditionException: 没有余额、金额不足或赎回失败时抛出，可等待下一轮重试
        """
        # 检查BFUSD余额
        if bfusd_balance is None:
            bfusd_balance = self.get_spot_balance('BFUSD')
        if bfusd_balance <= 0:
            logger.debug(f"没有BFUSD余额可赎回: {bfusd_balance}")
            raise TradingConditionException(f"没有BFUSD余额可赎回: {bfusd_balance}")

        # 检查快速赎回额度（如果未提供配额数据，则自动查询；如果提供则复用，避免重复查询）
        if quota_data is None:
            quota_data = self._check_redemption_quota()

        has_free_quota = quota_data['has_free_quota']
        free_quota = quota_data['free_quota']
        left_quota = quota_data['left_quota']
        minimum = quota_data['minimum']

        if has_free_quota:
            # 有免费额度：贪婪赎回，一次性赎回 min(当前持有的BFUSD, 免费额度)
            redeem_amount = min(bfusd_balance, free_quota)
            redeem_amount = int(redeem_amount)  # 转换为整数

            if redeem_amount < minimum:
                logger.warning(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}，等待下一轮")
                raise TradingConditionException(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}")

            logger.info(
                f"贪婪策略（有免费额度）：一次性赎回 {redeem_amount:.0f} BFUSD（当前余额: {bfusd_balance:.2f}, 可用免费额度: {free_quota:.2f}）")
        else:
            # 没有免费额度：只赎回购买的BFUSD数量
            if buy_quantity is None:
                logger.warning("没有免费额度时，必须提供购买的BFUSD数量")
                raise TradingConditionException("没有免费额度时，必须提供购买的BFUSD数量")

            # 确保赎回数量不超过余额和可用额度
            redeem_amount = min(bfusd_balance, left_quota, buy_quantity)
            redeem_amount = int(redeem_amount)  # 转换为整数

            if redeem_amount < minimum:
                logger.warning(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}，等待下一轮")
                raise TradingConditionException(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}")

            logger.info(
                f"精确赎回（无免费额度）：赎回 {redeem_amount:.0f} BFUSD（购买数量: {buy_quantity:.2f}, 当前余额: {bfusd_balance:.2f}, 可用额度: {left_quota:.2f}）")

        # 执行赎回（内部会遵守速率限制，失败时会抛出异常）
        return self.fast_redeem_bfusd(redeem_amount)

    @log_execution_time
    def _check_redemption_quota(self) -> Dict[str, Any]:
        """
        检查快速赎回额度
        
        Returns:
            包含额度信息的字典: {
                'free_quota': 免费额度（手续费为0）,
                'left_quota': 可用额度（超出免费部分手续费0.1%）,
                'has_free_quota': 是否有免费额度,
                'minimum': 最小赎回金额,
                'fee_rate': 手续费率
            }
            
        Raises:
            QuotaExhaustedException: leftQuota为0时抛出，需要退出进程
            TradingConditionException: 额度小于最小值时抛出，可等待下一轮重试
        """
        quota_info = self.get_fast_redemption_quota()
        fast_quota = quota_info['fast_redemption']
        free_quota = float(fast_quota.get('freeQuota', 0))
        left_quota = float(fast_quota.get('leftQuota', 0))
        minimum = float(fast_quota.get('minimum', 0.1))
        fee_rate = float(fast_quota.get('fee', 0))

        # leftQuota 为0时，无法完成快速赎回
        if left_quota <= 0:
            logger.warning(f"快速赎回剩余额度不足: leftQuota={left_quota}，无法完成快速赎回")
            raise QuotaExhaustedException(f"leftQuota已耗尽: {left_quota}")

        # freeQuota不能超过leftQuota
        free_quota = min(left_quota, free_quota)
        has_free_quota = free_quota > 0

        # 检查可用额度是否满足最小赎回金额要求
        # 如果没有免费额度，使用leftQuota；如果有免费额度，使用freeQuota
        available_quota = free_quota if has_free_quota else left_quota

        if available_quota < minimum:
            logger.warning(f"快速赎回可用额度不足: {available_quota} < {minimum}，等待下一轮")
            raise TradingConditionException(f"快速赎回可用额度不足: {available_quota} < {minimum}")

        if has_free_quota:
            logger.info(f"当前快速赎回免费额度: {free_quota}, 可用额度: {left_quota}")
        else:
            logger.info(f"当前快速赎回可用额度: {left_quota}（无免费额度，手续费0.1%）")

        return {
            'free_quota': free_quota,
            'left_quota': left_quota,
            'has_free_quota': has_free_quota,
            'minimum': minimum,
            'fee_rate': fee_rate
        }

    @log_execution_time
    def _validate_trading_conditions(
            self,
            symbol: str,
            has_free_quota: bool,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        验证交易条件（价格和订单簿流动性）
        
        Args:
            symbol: 交易对符号
            has_free_quota: 是否有免费额度
            must_profit: 是否必须盈利（仅在没有免费额度时生效）
            
        Returns:
            包含买入价格和订单簿信息的字典
            
        Raises:
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 获取订单簿（只获取一次，避免重复请求）
        order_book = self.get_order_book(symbol, limit=20)
        asks = order_book['asks']

        # 根据是否有免费额度选择不同的价格阈值
        if has_free_quota:
            # 有免费额度时，查找小于1.0的最低卖价
            price_threshold = 1.0
            price_comparison = lambda p: p < price_threshold
            error_msg = "订单簿中没有小于1.0的卖价，等待下一轮"
        else:
            # 没有免费额度时，查找小于等于0.999的最低卖价
            # 如果必须盈利，则必须小于0.999
            if must_profit:
                price_threshold = 0.999
                price_comparison = lambda p: p < price_threshold
                error_msg = "订单簿中没有小于0.999的卖价（必须盈利），等待下一轮"
            else:
                price_threshold = 0.999
                price_comparison = lambda p: p <= price_threshold
                error_msg = "订单簿中没有小于等于0.999的卖价，等待下一轮"

        # 从订单簿中查找最佳买入价格
        buy_price = None
        available_qty = 0.0
        for price, qty in asks:
            if price_comparison(price) and qty > 0:
                buy_price = price
                available_qty = qty
                break

        if buy_price is None:
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)

        logger.info(f"最佳买入价格: {buy_price}, 订单簿可用数量: {available_qty}")

        return {
            'buy_price': buy_price,
            'available_qty': available_qty,
            'order_book': order_book
        }

    def _calculate_buy_quantity(
            self,
            quota_data: Dict[str, Any],
            buy_price: float,
            per_round_amount: float
    ) -> int:
        """
        计算本轮的购买BFUSD数量，确保：数量为整数，订单总金额>5u，不超过单轮金额
        
        Args:
            quota_data: 快速赎回配额数据，包含 free_quota, left_quota, has_free_quota, minimum
            buy_price: 买入价格
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            
        Returns:
            购买数量（整数）
            
        Raises:
            TradingConditionException: 无法满足交易条件时抛出，可等待下一轮重试
        """
        free_quota = quota_data['free_quota']
        left_quota = quota_data['left_quota']
        has_free_quota = quota_data['has_free_quota']
        minimum = quota_data['minimum']

        # 1. 额度限制（转换为可买数量，向下取整）
        # 如果有免费额度，使用免费额度；如果没有免费额度，使用可用额度
        available_quota = free_quota if has_free_quota else left_quota
        max_qty_by_quota = int(available_quota)

        # 2. 单轮金额限制（转换为可买数量，向下取整）
        max_qty_by_round = int(per_round_amount / buy_price) if buy_price > 0 else 0

        # 取所有限制的最小值
        buy_qty = min(max_qty_by_quota, max_qty_by_round)

        if buy_qty <= 0:
            logger.warning(f"计算出的购买数量为0或负数: {buy_qty}，等待下一轮")
            raise TradingConditionException(f"无法计算有效购买数量: {buy_qty}")

        # 3. 确保满足最小赎回金额
        if buy_qty < minimum:
            logger.warning(f"购买数量 {buy_qty} 小于最小赎回金额 {minimum}，等待下一轮")
            raise TradingConditionException(f"购买数量 {buy_qty} 小于最小赎回金额 {minimum}")

        # 4. 确保订单总金额 > 5 USDT
        order_amount = buy_qty * buy_price
        if order_amount <= 5.0:
            logger.warning(f"订单总金额 {order_amount:.2f} USDT 不满足大于5 USDT的要求，等待下一轮")
            raise TradingConditionException(f"订单总金额 {order_amount:.2f} USDT 不满足大于5 USDT的要求")

        return buy_qty

    @log_execution_time
    def _execute_buy_order(
            self,
            symbol: str,
            buy_price: float,
            buy_quantity: float
    ) -> Dict[str, Any]:
        """
        执行买入订单并等待成交
        
        Args:
            symbol: 交易对符号
            buy_price: 买入价格
            buy_quantity: 买入数量
            
        Returns:
            包含订单信息的字典
            
        Raises:
            TradingConditionException: 订单执行失败时抛出，可等待下一轮重试
        """
        try:
            # BFUSDUSDT的数量精度是8位，价格精度是8位
            return super()._execute_buy_order(
                symbol=symbol,
                buy_price=buy_price,
                buy_quantity=buy_quantity,
                quantity_precision=8,
                price_precision=8,
                log_prefix="订单"
            )
        except Exception as e:
            logger.warning("订单执行失败，等待下一轮")
            raise TradingConditionException(f"订单执行失败: {str(e)}")

    def _calculate_cycle_result(
            self,
            cycle: int,
            avg_price: float,
            filled_qty: float,
            actual_cost: float,
            receive_amount: float,
            fee: float,
            total_operated: float,
            total_profit: float
    ) -> Dict[str, Any]:
        """
        计算单轮交易结果
        
        Args:
            cycle: 轮次
            avg_price: 平均买入价格
            filled_qty: 成交数量
            actual_cost: 实际成本
            receive_amount: 赎回收到金额
            fee: 手续费
            total_operated: 累计操作金额
            total_profit: 累计盈亏
            
        Returns:
            单轮交易结果字典
        """
        profit = receive_amount - actual_cost
        profit_rate = (profit / actual_cost) * 100 if actual_cost > 0 else 0

        return {
            'cycle': cycle,
            'buy_price': avg_price,
            'buy_quantity': filled_qty,
            'buy_cost': actual_cost,
            'redeem_receive': receive_amount,
            'fee': fee,
            'profit': profit,
            'profit_rate': profit_rate,
            'total_operated': total_operated,
            'total_profit': total_profit
        }

    @log_execution_time
    def _execute_single_trading_round(
            self,
            symbol: str,
            per_round_amount: float,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        执行单次交易循环：购买BFUSD -> 快速赎回
        
        Args:
            symbol: 交易对符号
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            must_profit: 是否必须盈利（仅在没有免费额度时生效）
            
        Returns:
            包含交易结果的字典: {
                'actual_cost': 实际买入成本,
                'receive_amount': 赎回收到的金额,
                'fee': 手续费,
                'profit': 盈亏,
                'profit_rate': 利润率（百分比）,
                'buy_price': 买入均价,
                'filled_qty': 成交数量
            }
            
        Raises:
            QuotaExhaustedException: leftQuota为0时抛出，需要退出进程
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 先查询配额，获取是否有免费额度的信息
        quota_data = self._check_redemption_quota()
        # 1. 循环开始时，先贪婪赎回所有残留的BFUSD（如果有）
        bfusd_balance = self.get_spot_balance('BFUSD')
        if bfusd_balance > 0:
            logger.info(f"检测到残留BFUSD余额: {bfusd_balance:.2f}，先执行贪婪赎回")
            try:
                # 传入已查询的余额，避免重复查询
                redeem_result = self._redeem_all_bfusd_greedy(bfusd_balance, quota_data=quota_data)
                logger.info(f"成功赎回残留BFUSD，收到 {redeem_result['receive_amount']:.2f} USDT")
            except TradingConditionException as e:
                # 清理残留失败（如余额不足、条件不满足等），不影响主流程，记录日志后继续
                logger.debug(f"清理残留BFUSD失败，继续主流程: {str(e)}")

        # 2. 检查是否可以继续操作（快速赎回额度、交易条件等）
        has_free_quota = quota_data['has_free_quota']

        # 根据是否有免费额度验证交易条件（价格阈值不同）
        trading_conditions = self._validate_trading_conditions(
            symbol=symbol,
            has_free_quota=has_free_quota,
            must_profit=must_profit
        )

        buy_price = trading_conditions['buy_price']

        # 3. 计算本轮购买数量（确保：整数，订单金额>5u，不超过单轮金额）
        buy_quantity = self._calculate_buy_quantity(
            quota_data=quota_data,
            buy_price=buy_price,
            per_round_amount=per_round_amount
        )

        order_amount = buy_quantity * buy_price
        logger.info(
            f"购买BFUSD: 数量={buy_quantity:.0f}, 价格={buy_price:.6f}, 订单金额={order_amount:.2f} USDT")

        # 4. 执行买入订单
        buy_result = self._execute_buy_order(symbol, buy_price, float(buy_quantity))

        # 5. 赎回BFUSD
        # 有免费额度：贪婪赎回 min(当前持有的BFUSD, 免费额度)
        # 没有免费额度：只赎回购买的BFUSD数量
        redeemed_bfusd_balance = buy_result['filled_qty']
        redeem_result = self._redeem_all_bfusd_greedy(
            bfusd_balance=redeemed_bfusd_balance,
            quota_data=quota_data,
            buy_quantity=float(buy_quantity) if not has_free_quota else None
        )

        # 6. 计算盈亏
        actual_cost = buy_result['actual_cost']
        receive_amount = redeem_result['receive_amount']
        fee = redeem_result['fee']
        profit = receive_amount - actual_cost
        profit_rate = (profit / actual_cost) * 100 if actual_cost > 0 else 0

        logger.info(
            f"交易完成: 成本={actual_cost:.4f} USDT, 收到={receive_amount:.4f} USDT, "
            f"手续费={fee:.4f}, 盈亏={profit:.4f} USDT ({profit_rate:.2f}%)")

        return {
            'actual_cost': actual_cost,
            'receive_amount': receive_amount,
            'fee': fee,
            'profit': profit,
            'profit_rate': profit_rate,
            'buy_price': buy_result['avg_price'],
            'filled_qty': buy_result['filled_qty']
        }

    @log_execution_time
    def execute_trading_cycle(
            self,
            per_round_amount: float,
            target_amount: Optional[float] = None,
            retry_wait_seconds: int = 5,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        执行交易循环：购买BFUSD -> 快速赎回 -> 重复
        
        Args:
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            target_amount: 目标操作金额（USDT），如果达到则停止
            retry_wait_seconds: 中断条件发生时，等待重试的秒数，默认5秒
            must_profit: 是否必须盈利（仅在没有免费额度时生效，买入价格必须<0.999）
            
        Returns:
            交易结果统计
        """
        symbol = "BFUSDUSDT"
        total_operated = 0.0  # 累计操作金额（USDT）
        total_bfusd_operated = 0.0  # 累计操作数量（BFUSD）
        total_profit = 0.0
        cycles = 0
        failed_attempts = 0
        results = []

        logger.info("=" * 50)
        logger.info("开始交易循环")
        logger.info(f"单轮最大金额: {per_round_amount} USDT")
        logger.info(f"目标金额: {target_amount}")
        logger.info(f"重试等待时间: {retry_wait_seconds}秒")
        logger.info(f"必须盈利: {must_profit}")
        logger.info("=" * 50)

        while True:  # 无限循环，通过break条件退出
            # 在循环开始检查是否达到目标金额
            if target_amount is not None and total_operated >= target_amount:
                logger.info(f"已达到目标金额 {target_amount} USDT，停止交易")
                break

            cycles += 1
            logger.info(f"\n--- 第 {cycles} 轮交易 ---")

            try:
                # 执行单次交易循环
                trading_result = self._execute_single_trading_round(
                    symbol, per_round_amount, must_profit=must_profit
                )

                # 交易成功，重置失败计数
                failed_attempts = 0

                # 更新累计数据
                actual_cost = trading_result['actual_cost']
                receive_amount = trading_result['receive_amount']
                filled_qty = trading_result['filled_qty']
                total_operated += actual_cost
                total_bfusd_operated += filled_qty
                total_profit += trading_result['profit']

                # 记录本轮结果
                cycle_result = self._calculate_cycle_result(
                    cycle=cycles,
                    avg_price=trading_result['buy_price'],
                    filled_qty=trading_result['filled_qty'],
                    actual_cost=actual_cost,
                    receive_amount=receive_amount,
                    fee=trading_result['fee'],
                    total_operated=total_operated,
                    total_profit=total_profit
                )
                results.append(cycle_result)

                profit = cycle_result['profit']
                profit_rate = cycle_result['profit_rate']
                logger.info(f"本轮盈亏: {profit:.4f} USDT ({profit_rate:.2f}%)")
                logger.info(f"累计操作: {total_bfusd_operated:.4f} BFUSD, 累计盈亏: {total_profit:.4f} USDT")

            except QuotaExhaustedException as e:
                # freeQuota或leftQuota已耗尽，直接退出进程
                logger.error(f"额度已耗尽，退出进程: {str(e)}")
                logger.info("=" * 50)
                logger.info("交易循环异常终止")
                logger.info(f"总循环数: {cycles}")
                logger.info(f"总操作数量: {total_bfusd_operated:.4f} BFUSD")
                logger.info(f"总盈亏: {total_profit:.4f} USDT")
                logger.info("=" * 50)
                sys.exit(1)

            except TradingConditionException as e:
                # 交易条件不满足，可忽略，等待下一轮重试
                logger.warning(f"第 {cycles} 轮交易条件不满足，等待下一轮: {str(e)}")
                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)
                continue

            except Exception as e:
                # 其他异常，保持原有逻辑：记录错误，等待后重试
                logger.error(f"第 {cycles} 轮交易出错: {str(e)}", exc_info=True)
                failed_attempts += 1

                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)

        summary = {
            'total_cycles': cycles,
            'total_operated': total_operated,
            'total_bfusd_operated': total_bfusd_operated,
            'total_profit': total_profit,
            'avg_profit_rate': (total_profit / total_operated * 100) if total_operated > 0 else 0,
            'results': results
        }

        logger.info("=" * 50)
        logger.info("交易循环结束")
        logger.info(f"总循环数: {cycles}")
        logger.info(f"总操作数量: {total_bfusd_operated:.4f} BFUSD")
        logger.info(f"总盈亏: {total_profit:.4f} USDT")
        if total_operated > 0:
            logger.info(f"平均利润率: {summary['avg_profit_rate']:.2f}%")
        logger.info("=" * 50)

        return summary


# 全局服务实例
_bfusd_service = None


def get_bfusd_service(
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        base_url: Optional[str] = None,
        proxy: Optional[str] = None
) -> BFUSDService:
    """
    获取BFUSD服务实例（单例模式）
    
    Args:
        api_key: 币安API密钥
        api_secret: 币安API密钥
        base_url: API基础URL
        proxy: 代理地址
        
    Returns:
        BFUSDService实例
    """
    global _bfusd_service
    if _bfusd_service is None:
        _bfusd_service = BFUSDService(
            api_key=api_key,
            api_secret=api_secret,
            base_url=base_url,
            proxy=proxy
        )
    return _bfusd_service
