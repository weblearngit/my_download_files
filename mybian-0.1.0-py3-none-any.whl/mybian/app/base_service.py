# -*- coding: utf-8 -*-
"""币安服务基类 - 提供通用的API调用方法"""
import time
import math
import hmac
import hashlib
import urllib.parse
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
import requests
from mybian.common.log_utils import get_logger, log_execution_time
from mybian.common.settings import settings

logger = get_logger(__name__)

# 币安API基础URL
BINANCE_API_BASE_URL = "https://api.binance.com"


# 自定义异常类
class TransferException(Exception):
    """资金划转异常基类"""
    pass


class InsufficientBalanceException(TransferException):
    """余额不足异常"""
    pass


class BaseBinanceService:
    """币安服务基类，提供通用的API调用方法"""

    def __init__(
            self,
            api_key: Optional[str] = None,
            api_secret: Optional[str] = None,
            base_url: str = BINANCE_API_BASE_URL,
            proxy: Optional[str] = None,
            timeout: int = 30
    ):
        """
        初始化币安服务基类
        
        Args:
            api_key: 币安API密钥
            api_secret: 币安API密钥
            base_url: API基础URL
            proxy: 代理地址，格式: http://user:pass@host:port 或 http://host:port
            timeout: 请求超时时间（秒）
        """
        self.api_key = api_key or settings.binance.api_key
        self.api_secret = api_secret or settings.binance.api_secret
        self.base_url = base_url or settings.binance.base_url
        self.proxy = proxy or settings.binance.proxy
        self.timeout = timeout

        # 配置代理
        self.proxies = None
        if self.proxy:
            self.proxies = {
                'http': self.proxy,
                'https': self.proxy
            }

        # 验证必要参数
        if not self.api_key or not self.api_secret:
            raise ValueError("API密钥和密钥必须配置")

        # 活期理财赎回速率限制：记录上次调用时间
        self.last_redeem_time = 0.0

        logger.info(f"币安服务初始化完成，API地址: {self.base_url}")
        if self.proxy:
            logger.info(f"使用代理: {self.proxy}")

    @log_execution_time
    def _generate_signature(self, params: Dict[str, Any]) -> str:
        """
        生成API请求签名
        
        Args:
            params: 请求参数字典
            
        Returns:
            HMAC SHA256签名字符串
        """
        query_string = urllib.parse.urlencode(params, doseq=True)
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature

    @log_execution_time
    def _make_request(
            self,
            method: str,
            endpoint: str,
            params: Optional[Dict[str, Any]] = None,
            signed: bool = True
    ) -> Dict[str, Any]:
        """
        发送API请求
        
        Args:
            method: HTTP方法 (GET, POST, DELETE)
            endpoint: API端点路径
            params: 请求参数
            signed: 是否需要签名
            
        Returns:
            API响应数据
        """
        if params is None:
            params = {}

        # 添加时间戳
        if signed:
            params['timestamp'] = int(time.time() * 1000)

        # 生成签名
        if signed:
            signature = self._generate_signature(params)
            params['signature'] = signature

        # 构建完整URL
        url = f"{self.base_url}{endpoint}"

        # 构建请求头
        headers = {
            'Accept': 'application/json',
            'X-MBX-APIKEY': self.api_key
        }

        try:
            # 发送请求
            method_upper = method.upper()
            if method_upper == 'GET':
                response = requests.get(
                    url,
                    params=params,
                    headers=headers,
                    proxies=self.proxies,
                    timeout=self.timeout
                )
            elif method_upper == 'POST':
                response = requests.post(
                    url,
                    params=params,
                    headers=headers,
                    proxies=self.proxies,
                    timeout=self.timeout
                )
            elif method_upper == 'DELETE':
                response = requests.delete(
                    url,
                    params=params,
                    headers=headers,
                    proxies=self.proxies,
                    timeout=self.timeout
                )
            else:
                raise ValueError(f"不支持的HTTP方法: {method}")

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            logger.error(f"API请求失败: {method} {endpoint} - {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    logger.error(f"错误响应: {error_data}")
                except Exception:
                    logger.error(f"错误响应: {e.response.text}")
            raise

    def _format_decimal(self, value: float, precision: int = 8) -> str:
        """
        格式化数值（数量或价格），符合币安精度要求
        
        Args:
            value: 数值（数量或价格）
            precision: 精度位数，默认8位
            
        Returns:
            格式化后的数值字符串（去除尾部零）
        """
        # 格式化为指定精度，然后去除尾部零
        format_str = f"{{:.{precision}f}}"
        formatted = format_str.format(value)
        # 去除尾部零和小数点
        if '.' in formatted:
            formatted = formatted.rstrip('0').rstrip('.')
        return formatted

    def _parse_utc_time_string(self, time_str: str) -> int:
        """
        将UTC时间字符串转换为UTC时间戳（毫秒）
        
        Args:
            time_str: UTC时间字符串，格式：%Y-%m-%d %H:%M:%S
            
        Returns:
            UTC时间戳（毫秒）
            
        Raises:
            ValueError: 如果时间格式错误
        """
        try:
            dt = datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
            dt_utc = dt.replace(tzinfo=timezone.utc)
            return int(dt_utc.timestamp() * 1000)
        except ValueError as e:
            raise ValueError(f"时间格式错误，应为 %Y-%m-%d %H:%M:%S 格式（UTC时间）: {e}")

    @log_execution_time
    def get_spot_balance(self, asset: str = "USDT") -> float:
        """
        获取现货账户余额
        
        Args:
            asset: 资产类型，默认USDT
            
        Returns:
            可用余额
        """
        endpoint = "/api/v3/account"
        response = self._make_request('GET', endpoint, signed=True)

        balances = response.get('balances', [])
        for balance in balances:
            if balance['asset'] == asset:
                return float(balance['free'])

        return 0.0

    @log_execution_time
    def get_order_status(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        查询订单状态

        Args:
            symbol: 交易对符号
            order_id: 订单ID

        Returns:
            订单状态数据
        """
        endpoint = "/api/v3/order"
        params = {
            'symbol': symbol,
            'orderId': order_id
        }

        response = self._make_request('GET', endpoint, params=params, signed=True)
        return response

    @log_execution_time
    def get_order_book(self, symbol: str = "BFUSDUSDT", limit: int = 10) -> Dict[str, Any]:
        """
        获取订单簿
        
        Args:
            symbol: 交易对符号
            limit: 返回深度数量，默认10
            
        Returns:
            订单簿数据
        """
        endpoint = "/api/v3/depth"
        params = {
            'symbol': symbol,
            'limit': limit
        }
        response = self._make_request('GET', endpoint, params=params, signed=False)

        bids = [(float(price), float(qty)) for price, qty in response.get('bids', [])]
        asks = [(float(price), float(qty)) for price, qty in response.get('asks', [])]

        return {
            'bids': bids,
            'asks': asks,
            'lastUpdateId': response.get('lastUpdateId')
        }

    def _place_limit_order_internal(
            self,
            symbol: str,
            side: str,
            quantity: float,
            price: float,
            quantity_precision: int = 8,
            price_precision: int = 8
    ) -> Dict[str, Any]:
        """
        内部下单方法，不包含余额不足的自动补救逻辑
        
        Args:
            symbol: 交易对符号
            side: 方向 (BUY/SELL)
            quantity: 数量
            price: 价格
            quantity_precision: 数量精度位数，默认8位
            price_precision: 价格精度位数，默认8位
            
        Returns:
            订单响应数据
        """
        endpoint = "/api/v3/order"

        # 格式化数量和价格，确保符合币安精度要求
        quantity_str = self._format_decimal(quantity, precision=quantity_precision)
        price_str = self._format_decimal(price, precision=price_precision)

        params = {
            'symbol': symbol,
            'side': side,
            'type': 'LIMIT',
            'timeInForce': 'GTC',  # Good Till Cancel
            'quantity': quantity_str,
            'price': price_str
        }

        response = self._make_request('POST', endpoint, params=params, signed=True)
        return response

    @log_execution_time
    def place_buy_limit_order(
            self,
            symbol: str,
            quantity: float,
            price: float,
            quantity_precision: int = 8,
            price_precision: int = 8
    ) -> Dict[str, Any]:
        """
        下买单 Limit 订单，如果余额不足会自动从活期理财赎回后重试
        
        Args:
            symbol: 交易对符号
            quantity: 数量
            price: 价格
            quantity_precision: 数量精度位数，默认8位
            price_precision: 价格精度位数，默认8位
            
        Returns:
            订单响应数据
        """
        side = 'BUY'
        try:
            response = self._place_limit_order_internal(
                symbol, side, quantity, price, quantity_precision, price_precision
            )
            logger.info(f"下单成功: {side} {quantity} {symbol} @ {price}, 订单ID: {response.get('orderId')}")
            return response
        except requests.exceptions.RequestException as e:
            # 检查是否是余额不足错误（code=-2010）
            error_code = None
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    error_code = error_data.get('code')
                except Exception:
                    pass

            # 如果是余额不足错误（code=-2010），则尝试自动补救
            if error_code == -2010:
                logger.warning(f"下单失败，余额不足（code=-2010），尝试从活期理财赎回后重试")

                # 计算下单金额（向上取整）
                order_amount = quantity * price
                required_amount = math.ceil(order_amount)
                logger.info(f"计算下单金额: {order_amount:.2f} USDT，向上取整后: {required_amount:.0f} USDT")

                # 确保现货余额
                try:
                    self.ensure_spot_usdt_balance(required_amount)
                    logger.info(f"已确保现货账户有足够的USDT余额: {required_amount:.0f} USDT")

                    # 等待一小段时间，确保资金到账
                    time.sleep(1)

                    # 重新提交订单（只重试一次）
                    response = self._place_limit_order_internal(
                        symbol, side, quantity, price, quantity_precision, price_precision
                    )
                    logger.info(
                        f"重试下单成功: {side} {quantity} {symbol} @ {price}, 订单ID: {response.get('orderId')}")
                    return response
                except Exception as transfer_error:
                    logger.error(f"自动补救失败: {str(transfer_error)}")
                    # 补救失败，抛出原始异常
                    raise e

            # 不是余额不足错误，直接抛出原始异常
            raise e

    @log_execution_time
    def wait_for_order_filled(
            self,
            symbol: str,
            order_id: int,
            max_wait_time: int = 60,
            check_interval: float = 1.0
    ) -> Optional[Dict[str, Any]]:
        """
        等待订单成交并返回订单状态信息
        
        Args:
            symbol: 交易对符号
            order_id: 订单ID
            max_wait_time: 最大等待时间（秒）
            check_interval: 检查间隔（秒）
            
        Returns:
            订单状态字典（如果订单已成交），None表示超时或被取消/拒绝
        """
        start_time = time.time()

        while time.time() - start_time < max_wait_time:
            order_status = self.get_order_status(symbol, order_id)
            status = order_status.get('status')

            if status == 'FILLED':
                logger.info(f"订单 {order_id} 已成交")
                return order_status
            elif status == 'CANCELED' or status == 'REJECTED':
                logger.error(f"订单 {order_id} 被取消或拒绝: {status}")
                return None

            time.sleep(check_interval)

        logger.warning(f"订单 {order_id} 等待超时")
        return None

    @log_execution_time
    def _execute_buy_order(
            self,
            symbol: str,
            buy_price: float,
            buy_quantity: float,
            quantity_precision: int = 8,
            price_precision: int = 8,
            log_prefix: str = "订单"
    ) -> Dict[str, Any]:
        """
        执行买入订单并等待成交
        
        Args:
            symbol: 交易对符号
            buy_price: 买入价格
            buy_quantity: 买入数量
            quantity_precision: 数量精度位数，默认8位
            price_precision: 价格精度位数，默认8位
            log_prefix: 日志前缀，用于区分不同的服务
            
        Returns:
            包含订单信息的字典
            
        Raises:
            Exception: 订单执行失败时抛出
        """
        # 下买单
        order_response = self.place_buy_limit_order(
            symbol=symbol,
            quantity=buy_quantity,
            price=buy_price,
            quantity_precision=quantity_precision,
            price_precision=price_precision
        )
        order_id = order_response['orderId']

        # 等待订单成交（返回订单状态信息，避免重复查询）
        order_status = self.wait_for_order_filled(symbol, order_id, max_wait_time=60)
        if order_status is None:
            logger.error("订单未在指定时间内成交，尝试取消订单")
            # 尝试取消订单
            try:
                cancel_endpoint = "/api/v3/order"
                self._make_request('DELETE', cancel_endpoint, params={
                    'symbol': symbol,
                    'orderId': order_id
                }, signed=True)
                logger.info(f"订单 {order_id} 已取消")
            except Exception as e:
                logger.error(f"取消订单失败: {str(e)}")
            logger.warning("订单执行失败，等待下一轮")
            raise Exception(f"订单 {order_id} 未在指定时间内成交")

        # 从已获取的订单状态中提取实际成交信息（避免重复查询）
        filled_qty = float(order_status.get('executedQty', 0))
        # 使用累积报价金额（cummulativeQuoteQty）除以数量得到实际均价
        cummulative_quote_qty = float(order_status.get('cummulativeQuoteQty', 0))
        if filled_qty > 0:
            avg_price = cummulative_quote_qty / filled_qty
        else:
            avg_price = float(order_status.get('price', buy_price))
        actual_cost = cummulative_quote_qty if cummulative_quote_qty > 0 else filled_qty * avg_price

        logger.info(f"{log_prefix}成交: 数量={filled_qty:.4f}, 均价={avg_price:.6f}, 成本={actual_cost:.4f} USDT")

        return {
            'filled_qty': filled_qty,
            'avg_price': avg_price,
            'actual_cost': actual_cost
        }

    @log_execution_time
    def _execute_sell_order(
            self,
            symbol: str,
            sell_price: float,
            sell_quantity: float,
            quantity_precision: int = 8,
            price_precision: int = 8,
            log_prefix: str = "卖出订单"
    ) -> Dict[str, Any]:
        """
        执行卖出订单并等待成交
        
        Args:
            symbol: 交易对符号
            sell_price: 卖出价格
            sell_quantity: 卖出数量
            quantity_precision: 数量精度位数，默认8位
            price_precision: 价格精度位数，默认8位
            log_prefix: 日志前缀，用于区分不同的服务
            
        Returns:
            包含订单信息的字典: {
                'filled_qty': 成交数量,
                'avg_price': 平均成交价格,
                'receive_amount': 实际收入
            }
            
        Raises:
            Exception: 订单执行失败时抛出
        """
        # 下卖单（直接调用内部方法，不涉及余额不足的自动补救逻辑）
        order_response = self._place_limit_order_internal(
            symbol=symbol,
            side='SELL',
            quantity=sell_quantity,
            price=sell_price,
            quantity_precision=quantity_precision,
            price_precision=price_precision
        )
        order_id = order_response['orderId']
        logger.info(f"下单成功: SELL {sell_quantity} {symbol} @ {sell_price}, 订单ID: {order_id}")

        # 等待订单成交（返回订单状态信息，避免重复查询）
        order_status = self.wait_for_order_filled(symbol, order_id, max_wait_time=60)
        if order_status is None:
            logger.error("订单未在指定时间内成交，尝试取消订单")
            # 尝试取消订单
            try:
                cancel_endpoint = "/api/v3/order"
                self._make_request('DELETE', cancel_endpoint, params={
                    'symbol': symbol,
                    'orderId': order_id
                }, signed=True)
                logger.info(f"订单 {order_id} 已取消")
            except Exception as e:
                logger.error(f"取消订单失败: {str(e)}")
            logger.warning("订单执行失败，等待下一轮")
            raise Exception(f"订单 {order_id} 未在指定时间内成交")

        # 从已获取的订单状态中提取实际成交信息（避免重复查询）
        filled_qty = float(order_status.get('executedQty', 0))
        # 使用累积报价金额（cummulativeQuoteQty）得到实际收入
        receive_amount = float(order_status.get('cummulativeQuoteQty', 0))
        if filled_qty > 0:
            avg_price = receive_amount / filled_qty
        else:
            avg_price = float(order_status.get('price', sell_price))

        logger.info(f"{log_prefix}成交: 数量={filled_qty:.4f}, 均价={avg_price:.6f}, 收入={receive_amount:.4f} USDT")

        return {
            'filled_qty': filled_qty,
            'avg_price': avg_price,
            'receive_amount': receive_amount
        }

    @log_execution_time
    def get_flexible_savings_balance(self, asset: str = "USDT") -> float:
        """
        获取活期理财余额
        
        Args:
            asset: 资产类型，默认USDT（目前仅支持USDT和BTC）
            
        Returns:
            可用余额（USDT或BTC）
        """
        endpoint = "/sapi/v1/simple-earn/account"
        response = self._make_request('GET', endpoint, signed=True)

        if asset.upper() == "USDT":
            return float(response.get('totalFlexibleAmountInUSDT', 0))
        elif asset.upper() == "BTC":
            return float(response.get('totalFlexibleAmountInBTC', 0))
        else:
            logger.warning(f"不支持的资产类型: {asset}，仅支持USDT和BTC")
            return 0.0

    @log_execution_time
    def redeem_flexible_savings(
            self,
            asset: str,
            amount: float,
            dest_account: str = "SPOT"
    ) -> Dict[str, Any]:
        """
        从活期理财赎回
        
        Args:
            asset: 资产类型，如USDT
            amount: 赎回金额
            dest_account: 目标账户，SPOT或FUND，默认SPOT
            
        Returns:
            赎回结果，包含redeemId和success字段
            
        Raises:
            ValueError: 如果资产类型不支持
            
        Note:
            速率限制: 1/3s per account，即每3秒最多调用一次
        """
        # 获取产品ID
        asset_upper = asset.upper()
        if asset_upper == "USDT":
            product_id = "USDT001"
        elif asset_upper == "BTC":
            product_id = "BTC001"
        else:
            raise ValueError(f"不支持的资产类型: {asset}，仅支持USDT和BTC")

        endpoint = "/sapi/v1/simple-earn/flexible/redeem"
        amount_str = self._format_decimal(amount, precision=8)
        params = {
            'productId': product_id,
            'amount': amount_str,
            'redeemAll': False,
            'destAccount': dest_account
        }

        # 遵守速率限制：1/3s per account，即至少间隔3秒
        current_time = time.time()
        time_since_last_redeem = current_time - self.last_redeem_time
        min_interval = 4  # 最小间隔3秒，设置为4秒更安全

        if time_since_last_redeem < min_interval:
            wait_time = min_interval - time_since_last_redeem
            logger.debug(f"遵守速率限制，等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)

        # 更新最后调用时间
        self.last_redeem_time = time.time()

        response = self._make_request('POST', endpoint, params=params, signed=True)

        if not response.get('success'):
            logger.error(f"活期理财赎回失败: {response}")
            raise TransferException(f"活期理财赎回失败: {response}")

        redeem_id = response.get('redeemId')
        logger.info(f"活期理财赎回成功: {amount_str} {asset}, 赎回ID: {redeem_id}")

        return response

    @log_execution_time
    def ensure_spot_usdt_balance(self, required_amount: float) -> Dict[str, Any]:
        """
        确保现货账户有足够的USDT余额，如果不足则从活期理财赎回
        
        流程：
        1. 检查现货账户USDT余额，将余额向下取整
        2. 如果向下取整后的余额足够则直接返回
        3. 如果不足，计算差额（目标金额 - 向下取整后的余额），尝试从活期理财赎回
        
        Args:
            required_amount: 需要的USDT金额
            
        Returns:
            包含操作结果的字典，格式：
            {
                'spot_balance': 现货账户最终余额,
                'redeemed_from_savings': 从活期理财赎回的金额,
                'operations': 操作记录列表
            }
            
        Raises:
            InsufficientBalanceException: 现货和活期理财余额都不足时抛出
        """
        operations = []
        redeemed_from_savings = 0.0

        # 1. 检查现货账户余额
        spot_balance = self.get_spot_balance('USDT')
        logger.info(f"现货账户USDT余额: {spot_balance:.2f}")

        # 2. 将现货余额向下取整
        spot_balance_floor = math.floor(spot_balance)
        logger.info(f"现货账户USDT余额（向下取整）: {spot_balance_floor:.0f}")

        if spot_balance_floor >= required_amount:
            logger.info(f"现货账户余额（向下取整后）充足，无需划转")
            return {
                'spot_balance': spot_balance,
                'redeemed_from_savings': 0.0,
                'operations': []
            }

        # 3. 计算需要赎回的金额（目标金额 - 向下取整后的余额）
        shortage = required_amount - spot_balance_floor
        logger.info(f"现货账户余额（向下取整后）不足，需要补充: {shortage:.2f} USDT")

        # 4. 尝试从活期理财赎回
        savings_balance = self.get_flexible_savings_balance('USDT')
        logger.info(f"活期理财USDT余额: {savings_balance:.2f}")

        if savings_balance > 0:
            redeem_amount = min(shortage, savings_balance)
            try:
                self.redeem_flexible_savings('USDT', redeem_amount)
                redeemed_from_savings = redeem_amount
                operations.append({
                    'type': 'redeem_from_savings',
                    'amount': redeem_amount,
                    'success': True
                })
                logger.info(f"从活期理财赎回 {redeem_amount:.2f} USDT")

                # 等待赎回完成（活期理财赎回可能需要一些时间）
                time.sleep(2)

                # 重新检查现货余额
                spot_balance = self.get_spot_balance('USDT')

                if spot_balance < required_amount:
                    logger.warning(
                        f"赎回后现货账户余额仍不足: {spot_balance:.2f} < {required_amount:.2f}"
                    )
            except Exception as e:
                logger.warning(f"从活期理财赎回失败: {str(e)}")
                operations.append({
                    'type': 'redeem_from_savings',
                    'amount': redeem_amount,
                    'success': False,
                    'error': str(e)
                })
        else:
            logger.warning("活期理财余额为0，无法赎回")

        # 5. 最终检查
        final_spot_balance = self.get_spot_balance('USDT')
        if final_spot_balance < required_amount:
            error_msg = (
                f"现货和活期理财余额都不足，无法满足需求: "
                f"需要 {required_amount:.2f} USDT, "
                f"现货余额 {final_spot_balance:.2f}, "
                f"已从活期理财赎回 {redeemed_from_savings:.2f}"
            )
            logger.error(error_msg)
            raise InsufficientBalanceException(error_msg)

        logger.info(f"资金划转完成，现货账户最终余额: {final_spot_balance:.2f} USDT")
        return {
            'spot_balance': final_spot_balance,
            'redeemed_from_savings': redeemed_from_savings,
            'operations': operations
        }

    @log_execution_time
    def get_all_order_lists(
            self,
            symbol: str = "USDCUSDT",
            start_time: Optional[str] = None,
            end_time: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        查询所有订单
        
        Args:
            symbol: 交易对符号，默认USDCUSDT
            start_time: 开始时间（UTC时间字符串，格式：%Y-%m-%d %H:%M:%S）
            end_time: 结束时间（UTC时间字符串，格式：%Y-%m-%d %H:%M:%S）
            
        Returns:
            订单数组，每个订单包含完整信息（status, executedQty, cummulativeQuoteQty, side等）
            
        Note:
            - startTime和endTime之间的时间差不能超过24小时
            - 时间字符串会被转换为UTC时间戳（毫秒）
            - 使用 /api/v3/allOrders 接口
        """
        endpoint = "/api/v3/allOrders"
        params: Dict[str, Any] = {
            'symbol': symbol,
            'limit': 1000
        }

        # 转换开始时间
        start_timestamp_ms = None
        if start_time is not None:
            start_timestamp_ms = self._parse_utc_time_string(start_time)
            params['startTime'] = start_timestamp_ms

        # 转换结束时间
        end_timestamp_ms = None
        if end_time is not None:
            end_timestamp_ms = self._parse_utc_time_string(end_time)
            params['endTime'] = end_timestamp_ms

        # 验证时间范围不超过24小时
        if start_timestamp_ms is not None and end_timestamp_ms is not None:
            time_diff = end_timestamp_ms - start_timestamp_ms
            max_diff = 24 * 60 * 60 * 1000  # 24小时（毫秒）
            if time_diff > max_diff:
                raise ValueError(f"时间范围不能超过24小时，当前范围: {time_diff / (60 * 60 * 1000):.2f} 小时")

        response = self._make_request('GET', endpoint, params=params, signed=True)

        # 直接返回列表
        return response if isinstance(response, list) else []

    @log_execution_time
    def get_trading_volume_statistics(
            self,
            symbol: str,
            start_time: str,
            end_time: str
    ) -> Dict[str, Any]:
        """
        统计指定交易对在指定时间范围内的交易量
        
        该方法使用 /api/v3/allOrders 接口获取订单列表，直接统计已成交订单的交易量。
        
        Args:
            symbol: 交易对符号，如 "BFUSDUSDT"
            start_time: 开始时间（UTC时间字符串，格式：%Y-%m-%d %H:%M:%S）
            end_time: 结束时间（UTC时间字符串，格式：%Y-%m-%d %H:%M:%S）
            
        Returns:
            包含统计信息的字典，格式：
            {
                'symbol': 交易对符号,
                'start_time': 开始时间（毫秒时间戳）,
                'end_time': 结束时间（毫秒时间戳）,
                'total_volume': 总交易量（基础资产数量）,
                'total_quote_volume': 总交易量（报价资产数量，如USDT）,
                'buy_volume': 买入交易量（基础资产数量）,
                'buy_quote_volume': 买入交易量（报价资产数量）,
                'sell_volume': 卖出交易量（基础资产数量）,
                'sell_quote_volume': 卖出交易量（报价资产数量）,
                'filled_order_count': 已成交订单数量,
                'total_order_count': 总订单数量
            }
            
        Raises:
            ValueError: 如果时间参数无效或时间范围超过24小时
        """
        # 转换时间字符串为时间戳
        start_timestamp_ms = self._parse_utc_time_string(start_time)
        end_timestamp_ms = self._parse_utc_time_string(end_time)

        if start_timestamp_ms >= end_timestamp_ms:
            raise ValueError("开始时间必须早于结束时间")

        # 验证时间范围不超过24小时
        time_diff = end_timestamp_ms - start_timestamp_ms
        max_diff = 24 * 60 * 60 * 1000  # 24小时（毫秒）
        if time_diff > max_diff:
            raise ValueError(f"时间范围不能超过24小时，当前范围: {time_diff / (60 * 60 * 1000):.2f} 小时")

        logger.info(f"开始统计交易量: {symbol}, 时间范围: {start_time} - {end_time}")

        # 初始化统计变量
        total_volume = 0.0
        total_quote_volume = 0.0
        buy_volume = 0.0
        buy_quote_volume = 0.0
        sell_volume = 0.0
        sell_quote_volume = 0.0
        filled_order_count = 0
        total_order_count = 0

        # 获取订单列表
        try:
            orders = self.get_all_order_lists(
                symbol=symbol,
                start_time=start_time,
                end_time=end_time
            )
            total_order_count = len(orders)
            logger.info(f"获取到 {total_order_count} 个订单")

            # 遍历每个订单，直接统计（订单信息已包含完整数据）
            for order in orders:
                status = order.get('status', '')

                # 只统计已成交的订单
                if status == 'FILLED':
                    filled_order_count += 1
                    side = order.get('side', '').upper()
                    executed_qty = float(order.get('executedQty', 0))
                    cummulative_quote_qty = float(order.get('cummulativeQuoteQty', 0))

                    # 累计统计
                    total_volume += executed_qty
                    total_quote_volume += cummulative_quote_qty

                    if side == 'BUY':
                        buy_volume += executed_qty
                        buy_quote_volume += cummulative_quote_qty
                    elif side == 'SELL':
                        sell_volume += executed_qty
                        sell_quote_volume += cummulative_quote_qty

            logger.info(
                f"交易量统计完成: {symbol}, "
                f"总交易量={total_volume:.4f}, "
                f"总报价交易量={total_quote_volume:.4f} USDT, "
                f"已成交订单数={filled_order_count}/{total_order_count}"
            )

        except Exception as e:
            logger.error(f"获取订单列表失败: {str(e)}")
            raise

        return {
            'symbol': symbol,
            'start_time': start_timestamp_ms,
            'end_time': end_timestamp_ms,
            'total_volume': total_volume,
            'total_quote_volume': total_quote_volume,
            'buy_volume': buy_volume,
            'buy_quote_volume': buy_quote_volume,
            'sell_volume': sell_volume,
            'sell_quote_volume': sell_quote_volume,
            'filled_order_count': filled_order_count,
            'total_order_count': total_order_count
        }
