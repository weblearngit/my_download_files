"""币安Alpha API服务"""
import httpx
from typing import Dict, Any
from datetime import datetime, timezone, timedelta
from collections import defaultdict

from mybian.common.log_utils import get_logger

logger = get_logger(__name__)

# 币安Alpha API基础URL
BINANCE_ALPHA_API_BASE_URL = "https://www.binance.com"


class BinanceAlphaService:
    """币安Alpha API服务类"""
    
    def __init__(self, base_url: str = BINANCE_ALPHA_API_BASE_URL, timeout: int = 10):
        """
        初始化币安Alpha服务
        
        Args:
            base_url: 币安Alpha API基础URL
            timeout: 请求超时时间（秒）
        """
        self.base_url = base_url
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=timeout)
    
    async def close(self):
        """关闭HTTP客户端"""
        await self.client.aclose()
    
    async def get_volume_by_start_date(
        self, 
        token: str, 
        start_date: str,
        base_value: float = 0.0,
        rank_count: int = 0
    ) -> list[Dict[str, Any]]:
        """
        获取币安Alpha指定代币从开始日期到当前时间的交易量，按小时统计并计算竞赛门槛
        
        Args:
            token: 代币代码，如 'ALPHA_177'（不带USDT后缀）
            start_date: 开始日期字符串，格式为 'YYYY-MM-DD'（UTC时间）
            base_value: 起始基础值（USDT），竞赛开始时的门槛金额
            rank_count: 上榜人数，排行榜上的人数
        
        Returns:
            按小时统计的列表，每个对象包含门槛增量和预计门槛（单位：USDT）
        """
        try:
            # 解析开始日期
            start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
            start_datetime = start_datetime.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
            
            # 结束时间为当前UTC时间
            end_datetime = datetime.now(timezone.utc)
            
            # 验证时间范围
            if start_datetime >= end_datetime:
                raise ValueError("开始日期不能晚于当前时间")
            
            # 计算时间跨度（小时）
            time_diff = end_datetime - start_datetime
            hours = int(time_diff.total_seconds() / 3600) + 1  # 加1确保包含当前时间
            
            # 币安Alpha API限制
            max_limit = 1000  # 单次请求最大限制
            
            # 使用币安Alpha专用的K线API
            # API格式: /bapi/defi/v1/public/alpha-trade/klines?interval=1h&limit={limit_hour}&symbol={token}USDT
            # symbol格式：ALPHA_177USDT（注意有下划线）
            symbol = f"{token.upper()}USDT"
            
            # 计算需要的数据量
            limit_hour = min(hours, max_limit)
            
            url = f"{self.base_url}/bapi/defi/v1/public/alpha-trade/klines"
            params = {
                "interval": "1h",
                "limit": limit_hour,
                "symbol": symbol
            }
            
            response = await self.client.get(url, params=params)
            response.raise_for_status()
            response_data = response.json()
            
            # 检查API响应
            if not response_data.get("success", False):
                raise Exception(f"币安Alpha API返回错误: {response_data.get('message', '未知错误')}")
            
            # 获取K线数据
            klines = response_data.get("data", [])
            
            if not klines:
                return []
            
            # 过滤出在时间范围内的K线
            start_timestamp = int(start_datetime.timestamp() * 1000)
            end_timestamp = int(end_datetime.timestamp() * 1000)
            
            all_klines = []
            for kline in klines:
                # K线数据格式：[时间戳(毫秒), 开盘价, 最高价, 最低价, 收盘价, 成交量, 收盘时间戳, 报价资产成交量, 成交笔数, ...]
                if isinstance(kline, list) and len(kline) >= 8:
                    kline_time = int(kline[0])  # K线开盘时间（毫秒）
                    if start_timestamp <= kline_time <= end_timestamp:
                        all_klines.append(kline)
            
            # 按时间戳排序（从早到晚）
            all_klines.sort(key=lambda x: int(x[0]))
            
            # 按小时统计交易量并计算门槛
            result = []
            cumulative_volume = 0.0  # 累计交易量（USDT）
            cumulative_threshold_increment = 0.0  # 累计门槛增量（USDT）
            previous_threshold = base_value  # 上一小时的预计门槛
            
            # UTC+8时区
            utc8_tz = timezone(timedelta(hours=8))
            
            for kline in all_klines:
                kline_time_ms = int(kline[0])  # K线开盘时间（毫秒）
                kline_datetime_utc = datetime.fromtimestamp(kline_time_ms / 1000, tz=timezone.utc)
                
                # 转换为UTC+8时区
                kline_datetime_utc8 = kline_datetime_utc.astimezone(utc8_tz)
                
                # 保留到小时，去掉分钟和秒
                kline_datetime_utc8_hour = kline_datetime_utc8.replace(minute=0, second=0, microsecond=0)
                
                # 获取报价资产成交量（USDT）
                quote_volume = float(kline[7])  # 报价资产成交量（USDT）
                cumulative_volume += quote_volume
                
                # 计算门槛增量
                # 如果有上榜人数，门槛增量 = 该小时交易量 / 上榜人数
                # 如果没有上榜人数，门槛增量 = 该小时交易量（假设每个人贡献相等）
                if rank_count > 0:
                    threshold_increment = quote_volume / rank_count
                else:
                    threshold_increment = quote_volume
                
                # 累计门槛增量
                cumulative_threshold_increment += threshold_increment
                
                # 计算预计门槛 = 起始基础值 + 累计交易量 / 上榜人数（如果有）
                # 或者 = 上一小时门槛 + 当前小时门槛增量
                if rank_count > 0:
                    # 方式1：基于累计交易量计算
                    estimated_threshold = base_value + (cumulative_volume / rank_count)
                else:
                    # 方式2：基于增量累加
                    estimated_threshold = previous_threshold + threshold_increment
                
                # 格式化金额为字符串，添加千分符，保留2位小数
                hour_volume_str = f"{quote_volume:,.2f}"
                cumulative_volume_str = f"{cumulative_volume:,.2f}"
                threshold_increment_str = f"{threshold_increment:,.2f}"
                cumulative_threshold_increment_str = f"{cumulative_threshold_increment:,.2f}"
                estimated_threshold_str = f"{estimated_threshold:,.2f}"
                
                # 格式化时间为 "UTC+8 2025-11-05 08" 格式
                datetime_str = f"UTC+8 {kline_datetime_utc8_hour.strftime('%Y-%m-%d %H')}"
                
                result.append({
                    "datetime": datetime_str,  # 小时开始时间（UTC+8），格式：UTC+8 YYYY-MM-DD HH
                    "hourVolume": hour_volume_str,  # 该小时交易量（USDT），字符串格式，带千分符
                    "cumulativeVolume": cumulative_volume_str,  # 累计交易量（USDT），字符串格式，带千分符
                    "thresholdIncrement": threshold_increment_str,  # 门槛增量（USDT），该小时对门槛的增量，字符串格式，带千分符
                    "cumulativeThresholdIncrement": cumulative_threshold_increment_str,  # 累计门槛增量（USDT），从开始累计到当前的门槛增量，字符串格式，带千分符
                    "estimatedThreshold": estimated_threshold_str,  # 预计门槛（USDT），字符串格式，带千分符
                })
                
                # 更新上一小时的预计门槛
                previous_threshold = estimated_threshold
            
            return result
            
        except ValueError as e:
            logger.error(f"时间格式错误: {str(e)}")
            raise Exception(f"时间格式错误: {str(e)}")
        except httpx.HTTPStatusError as e:
            logger.error(f"币安Alpha API请求失败: {e.response.status_code} - {e.response.text}")
            raise Exception(f"币安Alpha API请求失败: {e.response.status_code}")
        except httpx.RequestError as e:
            logger.error(f"币安Alpha API请求错误: {str(e)}")
            raise Exception(f"币安Alpha API请求错误: {str(e)}")


# 全局服务实例
_alpha_service = None


def get_alpha_service() -> BinanceAlphaService:
    """获取币安Alpha服务实例（单例模式）"""
    global _alpha_service
    if _alpha_service is None:
        _alpha_service = BinanceAlphaService()
    return _alpha_service

