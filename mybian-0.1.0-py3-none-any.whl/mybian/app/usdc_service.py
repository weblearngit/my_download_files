# -*- coding: utf-8 -*-
"""USDC交易服务 - 通过USDT买入USDC然后卖出USDC的循环交易"""
import time
from typing import Dict, Any, Optional
from mybian.common.log_utils import get_logger, log_execution_time
from mybian.app.base_service import BaseBinanceService, BINANCE_API_BASE_URL

logger = get_logger(__name__)


# 自定义异常类
class USDCTradingException(Exception):
    """USDC交易异常基类"""
    pass


class TradingConditionException(USDCTradingException):
    """交易条件不满足异常：可忽略，等待下一轮重试"""
    pass


class USDCService(BaseBinanceService):
    """USDC交易服务类"""

    def __init__(
            self,
            api_key: Optional[str] = None,
            api_secret: Optional[str] = None,
            base_url: str = BINANCE_API_BASE_URL,
            proxy: Optional[str] = None,
            timeout: int = 30
    ):
        """
        初始化USDC服务
        
        Args:
            api_key: 币安API密钥
            api_secret: 币安API密钥
            base_url: API基础URL
            proxy: 代理地址，格式: http://user:pass@host:port 或 http://host:port
            timeout: 请求超时时间（秒）
        """
        super().__init__(api_key, api_secret, base_url, proxy, timeout)
        logger.info(f"USDC服务初始化完成")


    @log_execution_time
    def _validate_trading_conditions(
            self,
            symbol: str
    ) -> Dict[str, Any]:
        """
        验证交易条件（价格和订单簿流动性）
        
        Args:
            symbol: 交易对符号
            
        Returns:
            包含买入价格、卖出价格和订单簿信息的字典
            
        Raises:
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 获取订单簿（只获取一次，避免重复请求）
        order_book = self.get_order_book(symbol, limit=20)
        asks = order_book['asks']
        bids = order_book['bids']

        # 查找最佳买入价格（最低卖价）
        buy_price = None
        buy_available_qty = 0.0
        for price, qty in asks:
            if qty > 0:
                buy_price = price
                buy_available_qty = qty
                break

        if buy_price is None:
            error_msg = "订单簿中没有可用的卖价，等待下一轮"
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)

        # 查找最佳卖出价格（最高买价）
        sell_price = None
        sell_available_qty = 0.0
        for price, qty in bids:
            if qty > 0:
                sell_price = price
                sell_available_qty = qty
                break

        if sell_price is None:
            error_msg = "订单簿中没有可用的买价，等待下一轮"
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)

        # 检查买卖价格差额限制（不能大于0.0001）
        price_diff = buy_price - sell_price
        if price_diff > 0.0001:
            error_msg = f"买卖价格差额 {price_diff:.6f} 超过限制 0.0001，等待下一轮"
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)

        logger.info(f"最佳买入价格: {buy_price}, 订单簿可用数量: {buy_available_qty}")
        logger.info(f"最佳卖出价格: {sell_price}, 订单簿可用数量: {sell_available_qty}")
        logger.info(f"价格差额: {price_diff:.6f} (限制: 0.0001)")

        return {
            'buy_price': buy_price,
            'sell_price': sell_price,
            'buy_available_qty': buy_available_qty,
            'sell_available_qty': sell_available_qty,
            'order_book': order_book
        }

    def _calculate_buy_quantity(
            self,
            buy_price: float,
            per_round_amount: float,
            target_amount: Optional[float] = None,
            total_operated_usdc: float = 0.0
    ) -> int:
        """
        计算本轮的购买USDC数量，确保：数量为整数，订单总金额不超过单轮金额，不超过目标金额
        
        Args:
            buy_price: 买入价格
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            target_amount: 目标操作金额（USDC），如果提供则确保不超过目标
            total_operated_usdc: 累计已操作数量（USDC）
            
        Returns:
            购买数量（整数，USDC）
            
        Raises:
            TradingConditionException: 无法满足交易条件时抛出，可等待下一轮重试
        """
        # 单轮金额限制（转换为可买数量，向下取整）
        max_qty_by_round = int(per_round_amount / buy_price) if buy_price > 0 else 0

        if max_qty_by_round <= 0:
            logger.warning(f"计算出的购买数量为0或负数: {max_qty_by_round}，等待下一轮")
            raise TradingConditionException(f"无法计算有效购买数量: {max_qty_by_round}")

        # 如果设置了目标金额，确保不超过目标
        if target_amount is not None:
            remaining = target_amount - total_operated_usdc
            if remaining <= 0:
                logger.warning(f"已达到目标操作金额，无需继续购买")
                raise TradingConditionException(f"已达到目标操作金额: {target_amount}")
            max_qty_by_round = min(max_qty_by_round, int(remaining))

        return max_qty_by_round

    @log_execution_time
    def _execute_buy_order(
            self,
            symbol: str,
            buy_price: float,
            buy_quantity: int
    ) -> Dict[str, Any]:
        """
        执行买入订单并等待成交
        
        Args:
            symbol: 交易对符号
            buy_price: 买入价格
            buy_quantity: 买入数量（整数，USDC）
            
        Returns:
            包含订单信息的字典
            
        Raises:
            TradingConditionException: 订单执行失败时抛出，可等待下一轮重试
        """
        try:
            # USDCUSDT的数量精度通常是2位（整数），价格精度是8位
            return super()._execute_buy_order(
                symbol=symbol,
                buy_price=buy_price,
                buy_quantity=float(buy_quantity),
                quantity_precision=2,
                price_precision=8,
                log_prefix="买入订单"
            )
        except Exception as e:
            logger.warning("订单执行失败，等待下一轮")
            raise TradingConditionException(f"订单执行失败: {str(e)}")

    @log_execution_time
    def _execute_sell_order(
            self,
            symbol: str,
            sell_price: float,
            sell_quantity: float
    ) -> Dict[str, Any]:
        """
        执行卖出订单并等待成交
        
        Args:
            symbol: 交易对符号
            sell_price: 卖出价格
            sell_quantity: 卖出数量（USDC）
            
        Returns:
            包含订单信息的字典
            
        Raises:
            TradingConditionException: 订单执行失败时抛出，可等待下一轮重试
        """
        # 下卖单（数量向下取整为整数）
        sell_quantity_int = int(sell_quantity)
        if sell_quantity_int <= 0:
            logger.warning(f"卖出数量无效: {sell_quantity_int}，等待下一轮")
            raise TradingConditionException(f"卖出数量无效: {sell_quantity_int}")

        # 使用基类的通用卖出订单方法
        try:
            return super()._execute_sell_order(
                symbol=symbol,
                sell_price=sell_price,
                sell_quantity=float(sell_quantity_int),
                quantity_precision=2,
                price_precision=8,
                log_prefix="卖出订单"
            )
        except Exception as e:
            logger.warning("订单执行失败，等待下一轮")
            raise TradingConditionException(f"订单执行失败: {str(e)}")

    def _calculate_cycle_result(
            self,
            cycle: int,
            buy_avg_price: float,
            buy_filled_qty: float,
            buy_actual_cost: float,
            sell_avg_price: float,
            sell_filled_qty: float,
            sell_receive_amount: float,
            total_operated_usdc: float,
            total_profit: float
    ) -> Dict[str, Any]:
        """
        计算单轮交易结果
        
        Args:
            cycle: 轮次
            buy_avg_price: 平均买入价格
            buy_filled_qty: 买入成交数量
            buy_actual_cost: 实际买入成本
            sell_avg_price: 平均卖出价格
            sell_filled_qty: 卖出成交数量
            sell_receive_amount: 卖出收到金额
            total_operated_usdc: 累计操作数量（USDC）
            total_profit: 累计盈亏
            
        Returns:
            单轮交易结果字典
        """
        profit = sell_receive_amount - buy_actual_cost
        profit_rate = (profit / buy_actual_cost) * 100 if buy_actual_cost > 0 else 0

        return {
            'cycle': cycle,
            'buy_price': buy_avg_price,
            'buy_quantity': buy_filled_qty,
            'buy_cost': buy_actual_cost,
            'sell_price': sell_avg_price,
            'sell_quantity': sell_filled_qty,
            'sell_receive': sell_receive_amount,
            'profit': profit,
            'profit_rate': profit_rate,
            'total_operated_usdc': total_operated_usdc,
            'total_profit': total_profit
        }

    @log_execution_time
    def _execute_single_trading_round(
            self,
            symbol: str,
            per_round_amount: float,
            target_amount: Optional[float] = None,
            total_operated_usdc: float = 0.0
    ) -> Dict[str, Any]:
        """
        执行单次交易循环：买入USDC -> 卖出USDC
        
        Args:
            symbol: 交易对符号
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            target_amount: 目标操作金额（USDC），如果提供则确保不超过目标
            total_operated_usdc: 累计已操作数量（USDC）
            
        Returns:
            包含交易结果的字典: {
                'buy_actual_cost': 实际买入成本（USDT）,
                'sell_receive_amount': 卖出收到的金额（USDT）,
                'profit': 盈亏（USDT）,
                'profit_rate': 利润率（百分比）,
                'buy_price': 买入均价,
                'buy_filled_qty': 买入成交数量（USDC）,
                'sell_price': 卖出均价,
                'sell_filled_qty': 卖出成交数量（USDC）
            }
            
        Raises:
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 1. 检查交易条件（价格和订单簿流动性）
        trading_conditions = self._validate_trading_conditions(symbol=symbol)

        buy_price = trading_conditions['buy_price']
        sell_price = trading_conditions['sell_price']

        # 2. 计算本轮购买数量（确保：整数，订单金额不超过单轮金额，不超过目标金额）
        buy_quantity = self._calculate_buy_quantity(
            buy_price=buy_price,
            per_round_amount=per_round_amount,
            target_amount=target_amount,
            total_operated_usdc=total_operated_usdc
        )

        order_amount = buy_quantity * buy_price
        logger.info(
            f"购买USDC: 数量={buy_quantity:.0f}, 价格={buy_price:.6f}, 订单金额={order_amount:.2f} USDT")

        # 3. 执行买入订单
        buy_result = self._execute_buy_order(symbol, buy_price, buy_quantity)

        # 4. 执行卖出订单（卖出买入的数量）
        sell_result = self._execute_sell_order(
            symbol=symbol,
            sell_price=sell_price,
            sell_quantity=buy_result['filled_qty']
        )

        # 5. 计算盈亏
        buy_actual_cost = buy_result['actual_cost']
        sell_receive_amount = sell_result['receive_amount']
        profit = sell_receive_amount - buy_actual_cost
        profit_rate = (profit / buy_actual_cost) * 100 if buy_actual_cost > 0 else 0

        logger.info(
            f"交易完成: 买入成本={buy_actual_cost:.4f} USDT, 卖出收入={sell_receive_amount:.4f} USDT, "
            f"盈亏={profit:.4f} USDT ({profit_rate:.2f}%)")

        return {
            'buy_actual_cost': buy_actual_cost,
            'sell_receive_amount': sell_receive_amount,
            'profit': profit,
            'profit_rate': profit_rate,
            'buy_price': buy_result['avg_price'],
            'buy_filled_qty': buy_result['filled_qty'],
            'sell_price': sell_result['avg_price'],
            'sell_filled_qty': sell_result['filled_qty']
        }

    @log_execution_time
    def execute_trading_cycle(
            self,
            per_round_amount: float,
            target_amount: Optional[float] = None,
            retry_wait_seconds: int = 5
    ) -> Dict[str, Any]:
        """
        执行交易循环：买入USDC -> 卖出USDC -> 重复
        
        Args:
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            target_amount: 目标操作金额（USDC），如果达到则停止
            retry_wait_seconds: 中断条件发生时，等待重试的秒数，默认5秒
            
        Returns:
            交易结果统计
        """
        symbol = "USDCUSDT"
        total_operated_usdc = 0.0  # 累计操作数量（USDC）
        total_cost = 0.0  # 累计成本（USDT）
        total_profit = 0.0  # 累计盈亏（USDT）
        cycles = 0
        failed_attempts = 0
        results = []

        logger.info("=" * 50)
        logger.info("开始交易循环")
        logger.info(f"单轮最大金额: {per_round_amount} USDT")
        logger.info(f"目标操作金额: {target_amount} USDC")
        logger.info(f"重试等待时间: {retry_wait_seconds}秒")
        logger.info("=" * 50)

        while True:  # 无限循环，通过break条件退出
            # 在循环开始检查是否达到目标金额
            if target_amount is not None and total_operated_usdc >= target_amount:
                logger.info(f"已达到目标操作金额 {target_amount} USDC，停止交易")
                break

            cycles += 1
            logger.info(f"\n--- 第 {cycles} 轮交易 ---")

            try:
                # 执行单次交易循环
                trading_result = self._execute_single_trading_round(
                    symbol, per_round_amount, target_amount, total_operated_usdc
                )

                # 交易成功，重置失败计数
                failed_attempts = 0

                # 更新累计数据
                buy_filled_qty = trading_result['buy_filled_qty']
                buy_actual_cost = trading_result['buy_actual_cost']
                total_operated_usdc += buy_filled_qty
                total_cost += buy_actual_cost
                total_profit += trading_result['profit']

                # 记录本轮结果
                cycle_result = self._calculate_cycle_result(
                    cycle=cycles,
                    buy_avg_price=trading_result['buy_price'],
                    buy_filled_qty=trading_result['buy_filled_qty'],
                    buy_actual_cost=trading_result['buy_actual_cost'],
                    sell_avg_price=trading_result['sell_price'],
                    sell_filled_qty=trading_result['sell_filled_qty'],
                    sell_receive_amount=trading_result['sell_receive_amount'],
                    total_operated_usdc=total_operated_usdc,
                    total_profit=total_profit
                )
                results.append(cycle_result)

                profit = cycle_result['profit']
                profit_rate = cycle_result['profit_rate']
                logger.info(f"本轮盈亏: {profit:.4f} USDT ({profit_rate:.2f}%)")
                logger.info(f"累计操作: {total_operated_usdc:.2f} USDC, 累计盈亏: {total_profit:.4f} USDT")

            except TradingConditionException as e:
                # 交易条件不满足，可忽略，等待下一轮重试
                logger.warning(f"第 {cycles} 轮交易条件不满足，等待下一轮: {str(e)}")
                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)
                continue

            except Exception as e:
                # 其他异常，保持原有逻辑：记录错误，等待后重试
                logger.error(f"第 {cycles} 轮交易出错: {str(e)}", exc_info=True)
                failed_attempts += 1

                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)

        summary = {
            'total_cycles': cycles,
            'total_operated_usdc': total_operated_usdc,
            'total_cost': total_cost,
            'total_profit': total_profit,
            'avg_profit_rate': (total_profit / total_cost * 100) if total_cost > 0 else 0,
            'results': results
        }

        logger.info("=" * 50)
        logger.info("交易循环结束")
        logger.info(f"总循环数: {cycles}")
        logger.info(f"总操作数量: {total_operated_usdc:.2f} USDC")
        logger.info(f"总成本: {total_cost:.4f} USDT")
        logger.info(f"总盈亏: {total_profit:.4f} USDT")
        if total_cost > 0:
            logger.info(f"平均利润率: {summary['avg_profit_rate']:.2f}%")
        logger.info("=" * 50)

        return summary


# 全局服务实例
_usdc_service = None


def get_usdc_service(
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        base_url: Optional[str] = None,
        proxy: Optional[str] = None
) -> USDCService:
    """
    获取USDC服务实例（单例模式）
    
    Args:
        api_key: 币安API密钥
        api_secret: 币安API密钥
        base_url: API基础URL
        proxy: 代理地址
        
    Returns:
        USDCService实例
    """
    global _usdc_service
    if _usdc_service is None:
        _usdc_service = USDCService(
            api_key=api_key,
            api_secret=api_secret,
            base_url=base_url,
            proxy=proxy
        )
    return _usdc_service

