# -*- coding: utf-8 -*-
"""RWUSD套利服务 - 通过USDT申购RWUSD，快速赎回为USDC，然后卖出USDC到USDT的套利流程"""
import time
import sys
import math
import requests
from typing import Dict, Any, Optional
from mybian.common.log_utils import get_logger, log_execution_time
from mybian.app.base_service import BaseBinanceService, BINANCE_API_BASE_URL

logger = get_logger(__name__)


# 自定义异常类
class RWUSDTradingException(Exception):
    """RWUSD交易异常基类"""
    pass


class QuotaExhaustedException(RWUSDTradingException):
    """额度耗尽异常：freeQuota或leftQuota为0，需要退出进程"""
    pass


class TradingConditionException(RWUSDTradingException):
    """交易条件不满足异常：可忽略，等待下一轮重试"""
    pass


class RWUSDService(BaseBinanceService):
    """RWUSD套利服务类"""

    def __init__(
            self,
            api_key: Optional[str] = None,
            api_secret: Optional[str] = None,
            base_url: str = BINANCE_API_BASE_URL,
            proxy: Optional[str] = None,
            timeout: int = 30
    ):
        """
        初始化RWUSD服务
        
        Args:
            api_key: 币安API密钥
            api_secret: 币安API密钥
            base_url: API基础URL
            proxy: 代理地址，格式: http://user:pass@host:port 或 http://host:port
            timeout: 请求超时时间（秒）
        """
        super().__init__(api_key, api_secret, base_url, proxy, timeout)

        # 快速赎回速率限制：记录上次调用时间
        self.last_rwusd_redeem_time = 0.0

        logger.info(f"RWUSD服务初始化完成")

    @log_execution_time
    def get_rwusd_account(self) -> Dict[str, Any]:
        """
        获取RWUSD账户信息
        
        Returns:
            包含rwusdAmount和totalProfit的字典
        """
        endpoint = "/sapi/v1/rwusd/account"
        response = self._make_request('GET', endpoint, signed=True)

        account_info = {
            'rwusd_amount': float(response.get('rwusdAmount', 0)),
            'total_profit': float(response.get('totalProfit', 0))
        }

        logger.info(f"RWUSD账户信息: {account_info}")
        return account_info

    @log_execution_time
    def get_rwusd_quota(self) -> Dict[str, Any]:
        """
        获取RWUSD配额详情
        
        Returns:
            包含subscriptionQuota、fastRedemptionQuota和standardRedemptionQuota的字典
        """
        endpoint = "/sapi/v1/rwusd/quota"
        response = self._make_request('GET', endpoint, signed=True)

        quota_info = {
            'subscription_quota': response.get('subscriptionQuota', {}),
            'fast_redemption_quota': response.get('fastRedemptionQuota', {}),
            'standard_redemption_quota': response.get('standardRedemptionQuota', {}),
            'subscribe_enable': response.get('subscribeEnable', False),
            'redeem_enable': response.get('redeemEnable', False)
        }

        logger.info(f"RWUSD配额信息: {quota_info}")
        return quota_info

    @log_execution_time
    def subscribe_rwusd(self, amount: float, asset: str = "USDT") -> Dict[str, Any]:
        """
        申购RWUSD，如果金额不足会自动从活期理财赎回后重试
        
        Args:
            amount: 申购数量（USDT）
            asset: 申购资产，默认USDT
            
        Returns:
            包含申购结果的字典
            
        Raises:
            TradingConditionException: 申购失败时抛出，可等待下一轮重试
            
        Note:
            速率限制: 1/3s per account，即每3秒最多调用一次
        """
        endpoint = "/sapi/v1/rwusd/subscribe"
        # 格式化数量，确保符合精度要求
        amount_str = self._format_decimal(amount, precision=8)
        params = {
            'asset': asset,
            'amount': amount_str
        }

        try:
            response = self._make_request('POST', endpoint, params=params, signed=True)
            rwusd_amount = float(response.get('rwusdAmount', 0))
            logger.info(f"申购RWUSD成功: 数量={amount_str} {asset}, 获得={rwusd_amount:.2f} RWUSD")

            return {
                'rwusd_amount': rwusd_amount,
                'subscribe_amount': amount
            }
        except requests.exceptions.RequestException as e:
            # 检查是否是金额不足错误（code=-9000）
            error_code = None
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_data = e.response.json()
                    error_code = error_data.get('code')
                except Exception:
                    pass

            # 如果是金额不足错误（code=-9000），则尝试自动补救
            if error_code == -9000:
                logger.warning(f"申购RWUSD失败，金额不足（code=-9000），尝试从活期理财赎回后重试")

                # 计算需要赎回的金额（向上取整）
                required_amount = math.ceil(amount)
                logger.info(f"计算申购金额: {amount:.2f} USDT，向上取整后: {required_amount:.0f} USDT")

                # 确保现货余额
                try:
                    self.ensure_spot_usdt_balance(required_amount)
                    logger.info(f"已确保现货账户有足够的USDT余额: {required_amount:.0f} USDT")

                    # 等待一小段时间，确保资金到账
                    time.sleep(1)

                    # 重新提交申购（只重试一次）
                    response = self._make_request('POST', endpoint, params=params, signed=True)
                    rwusd_amount = float(response.get('rwusdAmount', 0))
                    logger.info(f"重试申购RWUSD成功: 数量={amount_str} {asset}, 获得={rwusd_amount:.2f} RWUSD")

                    return {
                        'rwusd_amount': rwusd_amount,
                        'subscribe_amount': amount
                    }
                except Exception as transfer_error:
                    logger.error(f"自动补救失败: {str(transfer_error)}")
                    # 补救失败，抛出原始异常
                    raise e

            # 不是金额不足错误，直接抛出异常
            raise TradingConditionException(f"申购RWUSD失败: {str(e)}")
        except TradingConditionException:
            # 重新抛出交易条件异常
            raise
        except Exception as e:
            # 其他异常，包装为交易条件异常
            logger.error(f"申购RWUSD异常: {str(e)}")
            raise TradingConditionException(f"申购RWUSD异常: {str(e)}")

    @log_execution_time
    def fast_redeem_rwusd(self, amount: float) -> Dict[str, Any]:
        """
        快速赎回RWUSD（贪婪原则：尽可能多地使用免费额度）
        
        Args:
            amount: 赎回数量（RWUSD）
            
        Returns:
            包含赎回信息的字典
            
        Raises:
            TradingConditionException: 快速赎回失败时抛出，可等待下一轮重试
            
        Note:
            速率限制: 1/3s per account，即每3秒最多调用一次
        """
        endpoint = "/sapi/v1/rwusd/redeem"
        # 格式化数量，确保符合精度要求
        amount_str = self._format_decimal(amount, precision=8)
        params = {
            'amount': amount_str,
            'type': 'FAST'  # 快速赎回
        }

        # 遵守速率限制：1/3s per account，即至少间隔3秒
        current_time = time.time()
        time_since_last_redeem = current_time - self.last_rwusd_redeem_time
        min_interval = 4  # 最小间隔3秒，设置为4秒更安全

        if time_since_last_redeem < min_interval:
            wait_time = min_interval - time_since_last_redeem
            logger.debug(f"遵守速率限制，等待 {wait_time:.2f} 秒")
            time.sleep(wait_time)

        # 更新最后调用时间
        self.last_rwusd_redeem_time = time.time()

        response = self._make_request('POST', endpoint, params=params, signed=True)

        if not response.get('success'):
            logger.error(f"快速赎回失败: {response}")
            raise TradingConditionException(f"快速赎回失败: {response}")

        receive_amount = float(response.get('receiveAmount', 0))
        fee = float(response.get('fee', 0))

        logger.info(f"快速赎回成功: 数量={amount}, 收到={receive_amount:.2f} USDC, 手续费={fee:.2f}")

        return {
            'receive_amount': receive_amount,
            'fee': fee
        }

    @log_execution_time
    def _check_redemption_quota(self) -> Dict[str, Any]:
        """
        检查快速赎回额度
        
        Returns:
            包含额度信息的字典: {
                'free_quota': 免费额度（手续费为0，每天500u）,
                'left_quota': 可用额度（超出免费部分手续费0.1%）,
                'has_free_quota': 是否有免费额度,
                'minimum': 最小赎回金额,
                'fee_rate': 手续费率
            }
            
        Raises:
            QuotaExhaustedException: leftQuota为0时抛出，需要退出进程
            TradingConditionException: 额度小于最小值时抛出，可等待下一轮重试
        """
        quota_info = self.get_rwusd_quota()
        fast_quota = quota_info['fast_redemption_quota']
        free_quota = float(fast_quota.get('freeQuota', 0))
        left_quota = float(fast_quota.get('leftQuota', 0))
        minimum = float(fast_quota.get('minimum', 0.1))
        fee_rate = float(fast_quota.get('fee', 0))

        # leftQuota 为0时，无法完成快速赎回
        if left_quota <= 0:
            logger.warning(f"快速赎回剩余额度不足: leftQuota={left_quota}，无法完成快速赎回")
            raise QuotaExhaustedException(f"leftQuota已耗尽: {left_quota}")

        # freeQuota不能超过leftQuota
        free_quota = min(left_quota, free_quota)
        has_free_quota = free_quota > 0

        # 检查可用额度是否满足最小赎回金额要求
        # 如果没有免费额度，使用leftQuota；如果有免费额度，使用freeQuota
        available_quota = free_quota if has_free_quota else left_quota

        if available_quota < minimum:
            logger.warning(f"快速赎回可用额度不足: {available_quota} < {minimum}，等待下一轮")
            raise TradingConditionException(f"快速赎回可用额度不足: {available_quota} < {minimum}")

        if has_free_quota:
            logger.info(f"当前快速赎回免费额度: {free_quota}, 可用额度: {left_quota}")
        else:
            logger.info(f"当前快速赎回可用额度: {left_quota}（无免费额度，手续费0.1%）")

        return {
            'free_quota': free_quota,
            'left_quota': left_quota,
            'has_free_quota': has_free_quota,
            'minimum': minimum,
            'fee_rate': fee_rate
        }

    @log_execution_time
    def _redeem_all_rwusd_greedy(
            self,
            rwusd_balance: Optional[float] = None,
            quota_data: Optional[Dict[str, Any]] = None,
            buy_quantity: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        赎回RWUSD，根据是否有免费额度选择不同的赎回策略
        
        - 有免费额度：贪婪赎回，一次性赎回 min(当前持有的RWUSD, 免费额度)
        - 没有免费额度：只赎回购买的RWUSD数量
        
        Args:
            rwusd_balance: RWUSD余额，如果不提供则自动查询
            quota_data: 快速赎回配额数据，如果不提供则自动查询（避免重复查询）
            buy_quantity: 购买的RWUSD数量（仅在没有免费额度时使用）
        
        Returns:
            包含赎回信息的字典
            
        Raises:
            QuotaExhaustedException: 额度不足时抛出，需要退出进程
            TradingConditionException: 没有余额、金额不足或赎回失败时抛出，可等待下一轮重试
        """
        # 检查RWUSD余额
        if rwusd_balance is None:
            account_info = self.get_rwusd_account()
            rwusd_balance = account_info['rwusd_amount']
        if rwusd_balance <= 0:
            logger.debug(f"没有RWUSD余额可赎回: {rwusd_balance}")
            raise TradingConditionException(f"没有RWUSD余额可赎回: {rwusd_balance}")

        # 检查快速赎回额度（如果未提供配额数据，则自动查询；如果提供则复用，避免重复查询）
        if quota_data is None:
            quota_data = self._check_redemption_quota()

        has_free_quota = quota_data['has_free_quota']
        free_quota = quota_data['free_quota']
        left_quota = quota_data['left_quota']
        minimum = quota_data['minimum']

        if has_free_quota:
            # 有免费额度：贪婪赎回，一次性赎回 min(当前持有的RWUSD, 免费额度)
            redeem_amount = min(rwusd_balance, free_quota)
            redeem_amount = int(redeem_amount)  # 转换为整数

            if redeem_amount < minimum:
                logger.warning(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}，等待下一轮")
                raise TradingConditionException(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}")

            logger.info(
                f"贪婪策略（有免费额度）：一次性赎回 {redeem_amount:.0f} RWUSD（当前余额: {rwusd_balance:.2f}, 可用免费额度: {free_quota:.2f}）")
        else:
            # 没有免费额度：只赎回购买的RWUSD数量
            if buy_quantity is None:
                logger.warning("没有免费额度时，必须提供购买的RWUSD数量")
                raise TradingConditionException("没有免费额度时，必须提供购买的RWUSD数量")

            # 确保赎回数量不超过余额和可用额度
            redeem_amount = min(rwusd_balance, left_quota, buy_quantity)
            redeem_amount = int(redeem_amount)  # 转换为整数

            if redeem_amount < minimum:
                logger.warning(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}，等待下一轮")
                raise TradingConditionException(f"可赎回金额 {redeem_amount} 小于最小赎回金额 {minimum}")

            logger.info(
                f"精确赎回（无免费额度）：赎回 {redeem_amount:.0f} RWUSD（购买数量: {buy_quantity:.2f}, 当前余额: {rwusd_balance:.2f}, 可用额度: {left_quota:.2f}）")

        # 执行赎回（内部会遵守速率限制，失败时会抛出异常）
        return self.fast_redeem_rwusd(redeem_amount)

    @log_execution_time
    def _get_usdc_usdt_price(self) -> float:
        """
        获取USDC/USDT价格（从订单簿获取最佳买价，即卖出USDC时能获得的价格）
        
        Returns:
            USDC/USDT价格（1 USDC = X USDT）
            
        Raises:
            TradingConditionException: 无法获取价格时抛出
        """
        order_book = self.get_order_book("USDCUSDT", limit=1)
        bids = order_book['bids']
        
        if not bids or len(bids) == 0:
            error_msg = "无法获取USDC/USDT价格"
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)
        
        # 获取最佳买价（最高买价），即USDC的卖出价格
        price = bids[0][0]
        logger.info(f"USDC/USDT价格: {price:.6f}")
        return price

    @log_execution_time
    def _validate_trading_conditions(
            self,
            has_free_quota: bool,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        验证交易条件（USDC/USDT价格）
        
        Args:
            has_free_quota: 是否有免费额度
            must_profit: 是否必须盈利（仅在有免费额度时生效）
            
        Returns:
            包含USDC/USDT价格的字典
            
        Raises:
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 获取USDC/USDT价格
        usdc_usdt_price = self._get_usdc_usdt_price()

        # 根据是否有免费额度选择不同的价格阈值
        if has_free_quota:
            # 有免费额度时，如果要求必须盈利，则usdc/usdt > 1；不要求必须盈利时，可以等于1
            if must_profit:
                price_threshold = 1.0
                price_comparison = lambda p: p > price_threshold
                error_msg = "USDC/USDT价格不大于1.0（必须盈利），等待下一轮"
            else:
                price_threshold = 1.0
                price_comparison = lambda p: p >= price_threshold
                error_msg = "USDC/USDT价格小于1.0，等待下一轮"
        else:
            # 没有免费额度但有快速赎回额度时，如果usdc/usdt > 1.001，可以进行操作
            price_threshold = 1.001
            price_comparison = lambda p: p > price_threshold
            error_msg = "USDC/USDT价格不大于1.001（无免费额度），等待下一轮"

        if not price_comparison(usdc_usdt_price):
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)

        logger.info(f"交易条件满足: USDC/USDT价格={usdc_usdt_price:.6f}")

        return {
            'usdc_usdt_price': usdc_usdt_price
        }

    def _calculate_buy_quantity(
            self,
            quota_data: Dict[str, Any],
            per_round_amount: float
    ) -> int:
        """
        计算本轮的申购RWUSD数量（使用USDT），确保：数量为整数，订单总金额不超过单轮金额
        
        Args:
            quota_data: 快速赎回配额数据，包含 free_quota, left_quota, has_free_quota, minimum
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            
        Returns:
            申购数量（整数，USDT）
            
        Raises:
            TradingConditionException: 无法满足交易条件时抛出，可等待下一轮重试
        """
        free_quota = quota_data['free_quota']
        left_quota = quota_data['left_quota']
        has_free_quota = quota_data['has_free_quota']
        minimum = quota_data['minimum']

        # 1. 额度限制（转换为可申购数量，向下取整）
        # 如果有免费额度，使用免费额度；如果没有免费额度，使用可用额度
        available_quota = free_quota if has_free_quota else left_quota
        max_qty_by_quota = int(available_quota)

        # 2. 单轮金额限制（转换为可申购数量，向下取整）
        # 申购RWUSD使用USDT，所以直接使用per_round_amount
        max_qty_by_round = int(per_round_amount)

        # 取所有限制的最小值
        buy_qty = min(max_qty_by_quota, max_qty_by_round)

        if buy_qty <= 0:
            logger.warning(f"计算出的申购数量为0或负数: {buy_qty}，等待下一轮")
            raise TradingConditionException(f"无法计算有效申购数量: {buy_qty}")

        # 3. 确保满足最小赎回金额
        if buy_qty < minimum:
            logger.warning(f"申购数量 {buy_qty} 小于最小赎回金额 {minimum}，等待下一轮")
            raise TradingConditionException(f"申购数量 {buy_qty} 小于最小赎回金额 {minimum}")

        return buy_qty

    @log_execution_time
    def _sell_usdc_full(self, usdc_amount: float) -> Dict[str, Any]:
        """
        全额卖出USDC到USDT
        
        Args:
            usdc_amount: USDC数量
            
        Returns:
            包含卖出信息的字典
            
        Raises:
            TradingConditionException: 卖出失败时抛出，可等待下一轮重试
        """
        symbol = "USDCUSDT"
        
        # 获取订单簿，获取最佳卖出价格（最高买价）
        order_book = self.get_order_book(symbol, limit=1)
        bids = order_book['bids']
        
        if not bids or len(bids) == 0:
            error_msg = "订单簿中没有可用的买价，等待下一轮"
            logger.warning(error_msg)
            raise TradingConditionException(error_msg)
        
        sell_price = bids[0][0]
        
        # 下卖单（数量向下取整为整数）
        sell_quantity_int = int(usdc_amount)
        if sell_quantity_int <= 0:
            logger.warning(f"卖出数量无效: {sell_quantity_int}，等待下一轮")
            raise TradingConditionException(f"卖出数量无效: {sell_quantity_int}")

        # 使用基类的通用卖出订单方法
        try:
            return self._execute_sell_order(
                symbol=symbol,
                sell_price=sell_price,
                sell_quantity=float(sell_quantity_int),
                quantity_precision=2,
                price_precision=8,
                log_prefix="卖出USDC"
            )
        except Exception as e:
            logger.warning("卖出订单执行失败，等待下一轮")
            raise TradingConditionException(f"卖出订单执行失败: {str(e)}")

    @log_execution_time
    def _execute_single_trading_round(
            self,
            per_round_amount: float,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        执行单次交易循环：申购RWUSD -> 快速赎回为USDC -> 卖出USDC到USDT
        
        Args:
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            must_profit: 是否必须盈利（仅在有免费额度时生效）
            
        Returns:
            包含交易结果的字典: {
                'actual_cost': 实际申购成本（USDT）,
                'receive_amount': 卖出USDC收到的金额（USDT）,
                'fee': 赎回手续费,
                'profit': 盈亏（USDT）,
                'profit_rate': 利润率（百分比）,
                'subscribe_amount': 申购数量（USDT）,
                'rwusd_amount': 获得的RWUSD数量,
                'usdc_amount': 赎回获得的USDC数量
            }
            
        Raises:
            QuotaExhaustedException: leftQuota为0时抛出，需要退出进程
            TradingConditionException: 交易条件不满足时抛出，可等待下一轮重试
        """
        # 先查询配额，获取是否有免费额度的信息
        quota_data = self._check_redemption_quota()
        
        # 1. 循环开始时，先贪婪赎回所有残留的RWUSD（如果有）
        account_info = self.get_rwusd_account()
        rwusd_balance = account_info['rwusd_amount']
        if rwusd_balance > 0:
            logger.info(f"检测到残留RWUSD余额: {rwusd_balance:.2f}，先执行贪婪赎回")
            try:
                # 传入已查询的余额，避免重复查询
                redeem_result = self._redeem_all_rwusd_greedy(rwusd_balance, quota_data=quota_data)
                usdc_received = redeem_result['receive_amount']
                logger.info(f"成功赎回残留RWUSD，收到 {usdc_received:.2f} USDC")
                
                # 卖出获得的USDC
                sell_result = self._sell_usdc_full(usdc_received)
                logger.info(f"成功卖出残留USDC，收到 {sell_result['receive_amount']:.2f} USDT")
            except TradingConditionException as e:
                # 清理残留失败（如余额不足、条件不满足等），不影响主流程，记录日志后继续
                logger.debug(f"清理残留RWUSD失败，继续主流程: {str(e)}")

        # 2. 检查是否可以继续操作（快速赎回额度、交易条件等）
        has_free_quota = quota_data['has_free_quota']

        # 根据是否有免费额度验证交易条件（价格阈值不同）
        trading_conditions = self._validate_trading_conditions(
            has_free_quota=has_free_quota,
            must_profit=must_profit
        )

        # 3. 计算本轮申购数量（确保：整数，订单金额不超过单轮金额）
        subscribe_amount = self._calculate_buy_quantity(
            quota_data=quota_data,
            per_round_amount=per_round_amount
        )

        logger.info(
            f"申购RWUSD: 数量={subscribe_amount:.0f} USDT")

        # 4. 执行申购订单
        subscribe_result = self.subscribe_rwusd(float(subscribe_amount), asset="USDT")
        rwusd_amount = subscribe_result['rwusd_amount']

        # 5. 赎回RWUSD
        # 有免费额度：贪婪赎回 min(当前持有的RWUSD, 免费额度)
        # 没有免费额度：只赎回购买的RWUSD数量
        redeem_result = self._redeem_all_rwusd_greedy(
            rwusd_balance=rwusd_amount,
            quota_data=quota_data,
            buy_quantity=float(rwusd_amount) if not has_free_quota else None
        )

        usdc_amount = redeem_result['receive_amount']
        fee = redeem_result['fee']

        # 6. 卖出USDC到USDT（全额卖出）
        sell_result = self._sell_usdc_full(usdc_amount)

        # 7. 计算盈亏
        actual_cost = float(subscribe_amount)
        receive_amount = sell_result['receive_amount']
        profit = receive_amount - actual_cost
        profit_rate = (profit / actual_cost) * 100 if actual_cost > 0 else 0

        logger.info(
            f"交易完成: 成本={actual_cost:.4f} USDT, 收到={receive_amount:.4f} USDT, "
            f"手续费={fee:.4f}, 盈亏={profit:.4f} USDT ({profit_rate:.2f}%)")

        return {
            'actual_cost': actual_cost,
            'receive_amount': receive_amount,
            'fee': fee,
            'profit': profit,
            'profit_rate': profit_rate,
            'subscribe_amount': float(subscribe_amount),
            'rwusd_amount': rwusd_amount,
            'usdc_amount': usdc_amount
        }

    @log_execution_time
    def execute_trading_cycle(
            self,
            per_round_amount: float,
            target_amount: Optional[float] = None,
            retry_wait_seconds: int = 5,
            must_profit: bool = True
    ) -> Dict[str, Any]:
        """
        执行交易循环：申购RWUSD -> 快速赎回为USDC -> 卖出USDC到USDT -> 重复
        
        Args:
            per_round_amount: 单轮最大金额（USDT），限制每轮订单金额不超过此值
            target_amount: 目标操作金额（USDT），如果达到则停止
            retry_wait_seconds: 中断条件发生时，等待重试的秒数，默认1秒
            must_profit: 是否必须盈利（仅在有免费额度时生效，USDC/USDT价格必须>1.0）
            
        Returns:
            交易结果统计
        """
        total_operated = 0.0  # 累计操作金额（USDT）
        total_profit = 0.0
        cycles = 0
        failed_attempts = 0
        results = []

        logger.info("=" * 50)
        logger.info("开始RWUSD套利交易循环")
        logger.info(f"单轮最大金额: {per_round_amount} USDT")
        logger.info(f"目标金额: {target_amount}")
        logger.info(f"重试等待时间: {retry_wait_seconds}秒")
        logger.info(f"必须盈利: {must_profit}")
        logger.info("=" * 50)

        while True:  # 无限循环，通过break条件退出
            # 在循环开始检查是否达到目标金额
            if target_amount is not None and total_operated >= target_amount:
                logger.info(f"已达到目标金额 {target_amount} USDT，停止交易")
                break

            cycles += 1
            logger.info(f"\n--- 第 {cycles} 轮交易 ---")

            try:
                # 执行单次交易循环
                trading_result = self._execute_single_trading_round(
                    per_round_amount, must_profit=must_profit
                )

                # 交易成功，重置失败计数
                failed_attempts = 0

                # 更新累计数据
                actual_cost = trading_result['actual_cost']
                receive_amount = trading_result['receive_amount']
                total_operated += actual_cost
                total_profit += trading_result['profit']

                # 记录本轮结果
                cycle_result = {
                    'cycle': cycles,
                    'subscribe_amount': trading_result['subscribe_amount'],
                    'rwusd_amount': trading_result['rwusd_amount'],
                    'usdc_amount': trading_result['usdc_amount'],
                    'actual_cost': actual_cost,
                    'receive_amount': receive_amount,
                    'fee': trading_result['fee'],
                    'profit': trading_result['profit'],
                    'profit_rate': trading_result['profit_rate'],
                    'total_operated': total_operated,
                    'total_profit': total_profit
                }
                results.append(cycle_result)

                profit = cycle_result['profit']
                profit_rate = cycle_result['profit_rate']
                logger.info(f"本轮盈亏: {profit:.4f} USDT ({profit_rate:.2f}%)")
                logger.info(f"累计操作: {total_operated:.4f} USDT, 累计盈亏: {total_profit:.4f} USDT")

            except QuotaExhaustedException as e:
                # freeQuota或leftQuota已耗尽，直接退出进程
                logger.error(f"额度已耗尽，退出进程: {str(e)}")
                logger.info("=" * 50)
                logger.info("交易循环异常终止")
                logger.info(f"总循环数: {cycles}")
                logger.info(f"总操作金额: {total_operated:.4f} USDT")
                logger.info(f"总盈亏: {total_profit:.4f} USDT")
                logger.info("=" * 50)
                sys.exit(1)

            except TradingConditionException as e:
                # 交易条件不满足，可忽略，等待下一轮重试
                logger.warning(f"第 {cycles} 轮交易条件不满足，等待下一轮: {str(e)}")
                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)
                continue

            except Exception as e:
                # 其他异常，保持原有逻辑：记录错误，等待后重试
                logger.error(f"第 {cycles} 轮交易出错: {str(e)}", exc_info=True)
                failed_attempts += 1

                logger.info(f"等待 {retry_wait_seconds} 秒后重试...")
                time.sleep(retry_wait_seconds)

        summary = {
            'total_cycles': cycles,
            'total_operated': total_operated,
            'total_profit': total_profit,
            'avg_profit_rate': (total_profit / total_operated * 100) if total_operated > 0 else 0,
            'results': results
        }

        logger.info("=" * 50)
        logger.info("交易循环结束")
        logger.info(f"总循环数: {cycles}")
        logger.info(f"总操作金额: {total_operated:.4f} USDT")
        logger.info(f"总盈亏: {total_profit:.4f} USDT")
        if total_operated > 0:
            logger.info(f"平均利润率: {summary['avg_profit_rate']:.2f}%")
        logger.info("=" * 50)

        return summary


# 全局服务实例
_rwusd_service = None


def get_rwusd_service(
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        base_url: Optional[str] = None,
        proxy: Optional[str] = None
) -> RWUSDService:
    """
    获取RWUSD服务实例（单例模式）
    
    Args:
        api_key: 币安API密钥
        api_secret: 币安API密钥
        base_url: API基础URL
        proxy: 代理地址
        
    Returns:
        RWUSDService实例
    """
    global _rwusd_service
    if _rwusd_service is None:
        _rwusd_service = RWUSDService(
            api_key=api_key,
            api_secret=api_secret,
            base_url=base_url,
            proxy=proxy
        )
    return _rwusd_service

