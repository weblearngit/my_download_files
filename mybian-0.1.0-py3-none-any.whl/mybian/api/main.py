"""FastAPI 主应用入口"""
from pathlib import Path

from fastapi import FastAPI

from mybian.common.settings import settings
from mybian.common.log_utils import setup_logging, get_logger
from mybian.api.routers import binance_alpha

# 初始化日志
log_file_path = Path(settings.log.file) if settings.log.file else None
setup_logging(log_level=settings.log.level, log_file=log_file_path)
logger = get_logger(__name__)

# 创建 FastAPI 应用实例
app = FastAPI(
    title=settings.app.name,
    version=settings.app.version,
    debug=settings.app.debug
)

# 注册路由
app.include_router(binance_alpha.router)


@app.on_event("startup")
async def startup_event():
    """应用启动时的初始化"""
    logger.info(f"{settings.app.name} v{settings.app.version} 启动成功")
    logger.info(f"服务器地址: http://{settings.server.host}:{settings.server.port}")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭时的清理"""
    logger.info(f"{settings.app.name} 正在关闭...")
    # 关闭币安Alpha服务HTTP客户端
    from mybian.app.alpha_service import _alpha_service
    if _alpha_service:
        await _alpha_service.close()


@app.get("/")
async def root():
    """根路径"""
    return {
        "message": f"Welcome to {settings.app.name}",
        "version": settings.app.version
    }


@app.get("/health")
async def health():
    """健康检查"""
    return {"status": "healthy"}


def main():
    """应用入口函数"""
    import uvicorn
    uvicorn.run(
        "mybian.api.main:app",
        host=settings.server.host,
        port=settings.server.port,
        reload=settings.app.debug
    )
