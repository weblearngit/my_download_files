"""MyBian - 项目主模块"""

__version__ = "0.1.0"

