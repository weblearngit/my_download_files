"""币安Alpha相关路由"""
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from mybian.app.alpha_service import get_alpha_service
from mybian.common.log_utils import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/api/binance-alpha", tags=["币安Alpha"])


class AlphaThresholdItem(BaseModel):
    """币安Alpha竞赛门槛项"""
    datetime: str = Field(description="小时开始时间（UTC+8），格式：UTC+8 YYYY-MM-DD HH")
    hourVolume: str = Field(description="该小时交易量（USDT），字符串格式，带千分符")
    cumulativeVolume: str = Field(description="累计交易量（USDT），字符串格式，带千分符，从开始日期累计到当前小时")
    thresholdIncrement: str = Field(description="门槛增量（USDT），该小时对门槛的增量，字符串格式，带千分符")
    cumulativeThresholdIncrement: str = Field(description="累计门槛增量（USDT），从开始累计到当前的门槛增量，字符串格式，带千分符")
    estimatedThreshold: str = Field(description="预计门槛（USDT），基于累计交易量和上榜人数计算的预计门槛值，字符串格式，带千分符")


@router.get("/volume/{token}/range", response_model=list[AlphaThresholdItem], summary="获取币安Alpha指定代币交易竞赛门槛估算（按小时统计）")
async def get_alpha_volume_by_start_date(
    token: str,
    start_date: str = Query(..., description="开始日期（UTC），格式：YYYY-MM-DD，例如：2024-01-15"),
    base_value: float = Query(..., description="起始基础值（USDT），竞赛开始时的门槛金额"),
    rank_count: int = Query(..., description="上榜人数，排行榜上的人数，用于计算门槛增量")
):
    """
    获取币安Alpha指定代币从开始日期到当前时间的交易竞赛门槛估算，按小时统计
    
    用于估算Alpha交易竞赛的增量，根据交易量和上榜人数计算门槛增量及预计门槛。
    
    - **token**: 代币代码，如 ALPHA_177（不带USDT后缀，USDT是固定值）
    - **start_date**: 开始日期（UTC），格式：YYYY-MM-DD，例如：2024-01-15
    - **base_value**: 起始基础值（USDT），竞赛开始时的门槛金额
    - **rank_count**: 上榜人数，排行榜上的人数
    - 返回按小时统计的列表，每个对象包含：
      - datetime: 小时开始时间（UTC+8，格式：UTC+8 YYYY-MM-DD HH）
      - hourVolume: 该小时交易量（USDT），字符串格式，带千分符
      - cumulativeVolume: 累计交易量（USDT），字符串格式，带千分符，从开始日期累计到当前小时
      - thresholdIncrement: 门槛增量（USDT），该小时对门槛的增量，字符串格式，带千分符
      - cumulativeThresholdIncrement: 累计门槛增量（USDT），从开始累计到当前的门槛增量，字符串格式，带千分符
      - estimatedThreshold: 预计门槛（USDT），基于累计交易量和上榜人数计算的预计门槛值，字符串格式，带千分符
    
    计算逻辑：
    - 门槛增量 = 该小时交易量 / 上榜人数
    - 预计门槛 = 起始基础值 + (累计交易量 / 上榜人数)
    
    日期格式示例：
    - 2024-01-15
    """
    try:
        # 验证日期格式
        from datetime import datetime
        try:
            datetime.strptime(start_date, "%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=400, detail="日期格式错误，请使用 YYYY-MM-DD 格式")
        
        # 验证参数
        if base_value < 0:
            raise HTTPException(status_code=400, detail="起始基础值不能为负数")
        if rank_count <= 0:
            raise HTTPException(status_code=400, detail="上榜人数必须大于0")
        
        service = get_alpha_service()
        threshold_data = await service.get_volume_by_start_date(token, start_date, base_value, rank_count)
        return threshold_data
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取币安Alpha交易量失败: {str(e)}")
        error_msg = str(e)
        if "日期格式错误" in error_msg or "开始日期不能晚于当前时间" in error_msg:
            raise HTTPException(status_code=400, detail=error_msg)
        raise HTTPException(status_code=500, detail=f"获取币安Alpha交易量失败: {error_msg}")

